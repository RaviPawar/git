#include "TKAAppDelegate.hpp"
#include <QApplication>

int main(int argc, char *argv[])
{
  QApplication a(argc, argv);

  if (argc != 3)
  {
    std::cout << " Usage: " << argv[0] << " CaseIDFolder ImplantsFolder " << std::endl;
    exit(1);
  }

  TKAAppDelegate caseVisualizer;

  caseVisualizer.SetCaseIDAndImplantsFolder(argv[1], argv[2]);
  caseVisualizer.showFullScreen();

  return a.exec();
}
