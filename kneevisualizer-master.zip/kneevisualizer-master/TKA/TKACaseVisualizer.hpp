#ifndef TKACASEVISUALIZER_HPP
#define TKACASEVISUALIZER_HPP

#include "../Common/Renderer/SceneRenderer.hpp"
#include "../Common/Mappers/SphereMapper.hpp"
#include "../Common/Mappers/LineMapper.hpp"
#include "../Common/Mappers/SurfaceMapper.hpp"
#include "NavioTKADataLoader.hpp"
#include <QWidget>
#include <QCheckBox>


class TKACaseVisualizer : public QWidget
{
  Q_OBJECT

public:
  TKACaseVisualizer(const std::string& caseIDFolder,
                    const std::string& implantsFolder,
                    SceneRenderer *caseRenderer,
                    QWidget *parent = 0);
  ~TKACaseVisualizer();

private:
  void loadLandmarks();
  void loadFreeCollectionPoints();
  void loadAtlasSurfaces();
  void loadTrackerSurfaces();
  void loadPreOpROMData();
  void loadPostOpROMData();
  void loadImplants();
  void loadAxes();
  void addButtonsAndCheckBoxes();
  void makeSignalSlotConnections();

private slots:
  void slotToggleFemur();
  void slotToggleTibia();
  void slotToggleActor(int state);


private:

  void addActorToRenderer(vtkActor* actor, QString refFrameID, QString name);

  SceneRenderer *m_sceneRenderer;
  SphereMapper *m_femLandmarksMapper,
               *m_tibLandmarksMapper,
               *m_femurKneeCenterMapper,
               *m_femCheckPntMapper,
               *m_tibCheckPntMapper,
               *m_femFreeCollectionMapper,
               *m_tibFreeCollectionMapper;
  SurfaceMapper *m_femAtlasMapper,
                *m_tibAtlasMapper,
                *m_femTrackerMapper,
                *m_tibTrackerMapper;
  SurfaceMapper *m_femurImplantMapper,
                *m_tibiaImplantMapper;
  LineMapper *m_femurMechAxisMapper,
             *m_tibiaMechAxisMapper;
  QPushButton *m_femurButton,
              *m_tibiaButton;
  std::map<QCheckBox*, vtkActor*> m_checkBoxActorMap;
  NavioTKADataLoader* m_dataManager;
};

#endif // TKACASEVISUALIZER_HPP
