#ifndef VISUALIZERAPPDELEGATE_HPP
#define VISUALIZERAPPDELEGATE_HPP

#include <QMainWindow>
#include <iostream>

namespace Ui {
class AppDelegate;
}

class SceneRenderer;
class TKACaseVisualizer;

class TKAAppDelegate : public QMainWindow
{
  Q_OBJECT

public:
  explicit TKAAppDelegate(QWidget *parent = 0);
  ~TKAAppDelegate();

  void SetCaseIDAndImplantsFolder(std::string caseID, std::string implantsFolder);

protected:
  void launchAppWidget();
  void connectSignalsAndSlots();

protected slots:
  void slotQuit();

private:
  Ui::AppDelegate *m_ui;
  SceneRenderer *m_sceneRenderer;
  TKACaseVisualizer *m_tkavisualizer;

  std::string m_caseIDFolder;
  std::string m_implantsFolder;
};

#endif // VISUALIZERAPPDELEGATE_HPP
