#include "NavioTKADataLoader.hpp"
#include "../Common/Utils/VisualizerUtils.hpp"
#include <vtkTransform.h>
#include <vtkMath.h>
#include <sstream>
#include <iomanip>

using namespace std;

const unsigned int TKA_FEMUR_ML_REFERENCE_EPICONDYLES =       20;
const unsigned int TKA_FEMUR_ML_REFERENCE_WHITESIDE =         21;
const unsigned int TKA_FEMUR_ML_REFERENCE_POSTERIOR_CONDYLE = 22;

const unsigned int TKA_TIBIA_ROT_REFERENCE_AP =           30;
const unsigned int TKA_TIBIA_ROT_REFERENCE_TUBERCLE =     32;
const unsigned int TKA_TIBIA_ROT_REFERENCE_FEMUR =        33;

const unsigned int TKA_OPERATIVE_SIDE_LEFT = 1;
const unsigned int TKA_OPERATIVE_SIDE_RIGHT = 2;


void getPoint(vtkPoints* source, int index, double point[3])
{
  point[0] = source->GetPoint((vtkIdType)index)[0];
  point[1] = source->GetPoint((vtkIdType)index)[1];
  point[2] = source->GetPoint((vtkIdType)index)[2];
}

/**
 * @brief      Constructs the object.
 */
NavioTKADataLoader::NavioTKADataLoader(const std::string& caseDataFolder, const std::string& implantFolder):
  m_femoralKneeCenter(NULL),
  m_femoralHipCenter(NULL),
  m_femoralLandmarks(NULL),
  m_femoralCheckpoint(NULL),
  m_femoralFreeCollectionPoints(NULL),
  m_femoralAtlasSurface(NULL),
  m_femoralImplantSurface(NULL),
  m_tibialKneeCenter(NULL),
  m_tibialAverageMalleoli(NULL),
  m_tibialLandmarks(NULL),
  m_tibialCheckpoint(NULL),
  m_tibialFreeCollectionPoints(NULL),
  m_tibialAtlasSurface(NULL),
  m_tibialImplantSurface(NULL),
  m_caseDataFolder(caseDataFolder),
  m_implantFolder(implantFolder)
{
  loadData();
  updateFemurAnatomicTransfoms();
  updateTibiaAnatomicTransfoms();
  loadROMS();
  loadImplants();

}

/**
 * @brief      Destroys the object.
 */
NavioTKADataLoader::~NavioTKADataLoader()
{
}

/**
 * @brief      Gets the femoral landmark points.
 *
 * @return     The femoral landmark points.
 */
vtkPoints* NavioTKADataLoader::GetFemoralLandmarkPoints()
{
  return m_femoralLandmarks;
}

/**
 * @brief      Gets the femoral check point.
 *
 * @return     The femoral check point.
 */
vtkPoints* NavioTKADataLoader::GetFemoralCheckPoint()
{
  return m_femoralCheckpoint;
}

/**
 * @brief      Gets the femoral knee center.
 *
 * @return     The femoral knee center.
 */
vtkPoints* NavioTKADataLoader::GetFemoralKneeCenter()
{
  return m_femoralKneeCenter;
}

/**
 * @brief      Gets the femoral hip center.
 *
 * @return     The femoral hip center.
 */
vtkPoints* NavioTKADataLoader::GetFemoralHipCenter()
{
  return m_femoralHipCenter;
}

/**
 * @brief      Gets the femoral free collection points.
 *
 * @return     The femoral free collection points.
 */
vtkPoints* NavioTKADataLoader::GetFemoralFreeCollectionPoints()
{
  return m_femoralFreeCollectionPoints;
}

/**
 * @brief      Gets the femoral atlas surface.
 *
 * @return     The femoral atlas surface.
 */
vtkPolyData* NavioTKADataLoader::GetFemoralAtlasSurface()
{
  return m_femoralAtlasSurface;
}

/**
 * @brief      Gets the femoral implant surface.
 *
 * @return     The femoral implant surface.
 */
vtkPolyData* NavioTKADataLoader::GetFemoralImplantSurface()
{
  return m_femoralImplantSurface;
}

/**
 * @brief      Gets the femoral implant to femoral anatomic transform.
 *
 * @return     The femoral implant to femoral anatomic transform.
 */
vtkMatrix4x4* NavioTKADataLoader::GetFemoralImplantToFemoralAnatomicTransform()
{

  return m_faTfi;
}

/**
 * @brief      Gets the femoral tracker to femoral anatomic transform.
 *
 * @return     The femoral tracker to femoral anatomic transform.
 */
vtkMatrix4x4* NavioTKADataLoader::GetFemoralTrackerToFemoralAnatomicTransform()
{
  return m_faTft;
}

/**
 * @brief      Gets the tibial landmark points.
 *
 * @return     The tibial landmark points.
 */
vtkPoints* NavioTKADataLoader::GetTibialLandmarkPoints()
{
  return m_tibialLandmarks;
}

/**
 * @brief      Gets the tibial check point.
 *
 * @return     The tibial check point.
 */
vtkPoints* NavioTKADataLoader::GetTibialCheckPoint()
{
  return m_tibialCheckpoint;
}

/**
 * @brief      Gets the tibial knee center.
 *
 * @return     The tibial knee center.
 */
vtkPoints* NavioTKADataLoader::GetTibialKneeCenter()
{
  return m_tibialKneeCenter;
}

/**
 * @brief      Gets the tibial average malleoli.
 *
 * @return     The tibial average malleoli.
 */
vtkPoints* NavioTKADataLoader::GetTibialAverageMalleoli()
{
  return m_tibialAverageMalleoli;
}

/**
 * @brief      Gets the tibial free collection points.
 *
 * @return     The tibial free collection points.
 */
vtkPoints* NavioTKADataLoader::GetTibialFreeCollectionPoints()
{
  return m_tibialFreeCollectionPoints;
}

/**
 * @brief      Gets the tibial atlas surface.
 *
 * @return     The tibial atlas surface.
 */
vtkPolyData* NavioTKADataLoader::GetTibialAtlasSurface()
{
  return m_tibialAtlasSurface;
}

/**
 * @brief      Gets the femoral implant surface.
 *
 * @return     The femoral implant surface.
 */
vtkPolyData* NavioTKADataLoader::GetTibialImplantSurface()
{
  return m_tibialImplantSurface;
}

/**
 * @brief      Gets the tibia implant to tibial anatomic transform.
 *
 * @return     The tibia implant to tibial anatomic transform.
 */
vtkMatrix4x4* NavioTKADataLoader::GetTibiaImplantToTibialAnatomicTransform()
{
  return m_taTti;
}

/**
 * @brief      Gets the tibia tracker to tibial anatomic transform.
 *
 * @return     The tibia tracker to tibial anatomic transform.
 */
vtkMatrix4x4* NavioTKADataLoader::GetTibiaTrackerToTibialAnatomicTransform()
{
  return m_taTtt;
}

vtkMatrix4x4* NavioTKADataLoader::GetTibiaTrackerToFemoralAnatomicTransform()
{
  return m_faTtt;
}

/**
 * @brief      Gets the tibia implant to femoral anatomic transform.
 *
 * @return     The tibia implant to femoral anatomic transform.
 */
vtkMatrix4x4* NavioTKADataLoader::GetTibiaImplantToFemoralAnatomicTransform()
{
  return m_faTti;
}

/**
 * @brief      Gets the neutral flexion matrix.
 *
 * @return     The neutral flexion matrix.
 */
std::vector<vtkSmartPointer<vtkMatrix4x4> > NavioTKADataLoader::GetNeutralFlexionMat()
{
  return m_neutralFlexionMat;
}

/**
 * @brief      Gets the femur non stressed rom collection.
 *
 * @return     The femur non stressed rom collection.
 */
std::vector<vtkSmartPointer<vtkMatrix4x4> > NavioTKADataLoader::GetFemurNonStressedROMCollection()
{
  return m_femurNonStressedROMCollection;
}

/**
 * @brief      Gets the femur t tibia rom stress medial.
 *
 * @return     The femur t tibia rom stress medial.
 */
std::vector<vtkSmartPointer<vtkMatrix4x4> > NavioTKADataLoader::GetFemurTTibiaROMStressMedial()
{
  return m_femurTTibiaROMStressMedial;
}

/**
 * @brief      Gets the femur t tibia rom stress lateral.
 *
 * @return     The femur t tibia rom stress lateral.
 */
std::vector<vtkSmartPointer<vtkMatrix4x4> > NavioTKADataLoader::GetFemurTTibiaROMStressLateral()
{
  return m_femurTTibiaROMStressLateral;
}

/**
 * @brief      Gets the femur t tibia post operation medial baseline rom.
 *
 * @return     The femur t tibia post operation medial baseline rom.
 */
std::vector<vtkSmartPointer<vtkMatrix4x4> > NavioTKADataLoader::GetFemurTTibiaPostOpMedialBaselineROM()
{
  return m_femurTTibiaPostOpMedialBaselineROM;
}

/**
 * @brief      Gets the femur t tibia post operation lateral baseline rom.
 *
 * @return     The femur t tibia post operation lateral baseline rom.
 */
std::vector<vtkSmartPointer<vtkMatrix4x4> > NavioTKADataLoader::GetFemurTTibiaPostOpLateralBaselineROM()
{
  return m_femurTTibiaPostOpLateralBaselineROM;
}

/**
 * @brief      Gets the femur t tibia post operation rom stress medial.
 *
 * @return     The femur t tibia post operation rom stress medial.
 */
std::vector<vtkSmartPointer<vtkMatrix4x4> > NavioTKADataLoader::GetFemurTTibiaPostOpROMStressMedial()
{
  return m_femurTTibiaPostOpROMStressMedial;
}

/**
 * @brief      Gets the femur t tibia post operation rom stress lateral.
 *
 * @return     The femur t tibia post operation rom stress lateral.
 */
std::vector<vtkSmartPointer<vtkMatrix4x4> > NavioTKADataLoader::GetFemurTTibiaPostOpROMStressLateral()
{
  return m_femurTTibiaPostOpROMStressLateral;
}


/**
 * @brief      Loads case data.
 */
void NavioTKADataLoader::loadData()
{

  // Load Femoral Atlas Surface
  m_femoralAtlasSurface = VisualizerUtils::ImportSurface(m_caseDataFolder + "/intraop/NTKR_FemurAtlasSurface.sur");

  // Load Femoral Free Collection Points
  m_femoralFreeCollectionPoints = VisualizerUtils::ImportPoints(m_caseDataFolder + "/intraop/NTKR_FemFreeCollectionPts.mat");

  // Femoral Knee Center
  m_femoralKneeCenter =  VisualizerUtils::ImportPoints(m_caseDataFolder + "/intraop/NTKR_FemKneeCenter.mat");

  //Femoral Checkpoint
  m_femoralCheckpoint = VisualizerUtils::ImportPoints(m_caseDataFolder + "/intraop/NTKR_FemLandmark.mat");

  //Femoral Landmarks
  m_maxPosteriorLateralPoint = VisualizerUtils::ImportPoints(m_caseDataFolder + "/intraop/NTKR_FemMaxPostLatPt.mat");
  m_maxPosteriorMedialPoint = VisualizerUtils::ImportPoints(m_caseDataFolder + "/intraop/NTKR_FemMaxPostMedPt.mat");
  vtkSmartPointer<vtkPoints> maxAnteriorPoint = VisualizerUtils::ImportPoints(m_caseDataFolder + "/intraop/NTKR_FemMaxAntPt.mat");
  m_femoralHipCenter = VisualizerUtils::ImportPoints(m_caseDataFolder + "/intraop/NTKR_FemHipCenter.mat");

  m_femoralLandmarks = vtkSmartPointer<vtkPoints>::New();
  VisualizerUtils::AppendPoints(m_femoralKneeCenter, m_femoralLandmarks);
  VisualizerUtils::AppendPoints(m_maxPosteriorLateralPoint, m_femoralLandmarks);
  VisualizerUtils::AppendPoints(m_maxPosteriorMedialPoint, m_femoralLandmarks);
  VisualizerUtils::AppendPoints(maxAnteriorPoint, m_femoralLandmarks);
  VisualizerUtils::AppendPoints(m_femoralHipCenter, m_femoralLandmarks);
  try
  {
    m_lateralEpicondyle = VisualizerUtils::ImportPoints(m_caseDataFolder + "/intraop/NTKR_FemLatEpi.mat");
    m_medialEpicondyle = VisualizerUtils::ImportPoints(m_caseDataFolder + "/intraop/NTKR_FemMedEpi.mat");
    VisualizerUtils::AppendPoints(m_lateralEpicondyle, m_femoralLandmarks);
    VisualizerUtils::AppendPoints(m_medialEpicondyle, m_femoralLandmarks);
  }
  catch (const runtime_error& error)
  {
    std::cerr << "Epicondyles were not selected as reference!" << std::endl;
  }


  std::vector< vtkSmartPointer<vtkMatrix4x4> > neutralTransforms = VisualizerUtils::ImportMatrix(m_caseDataFolder + "/intraop/NTKR_NeutralFlexionMat.mat");
  m_ftTttNeutral = vtkSmartPointer<vtkMatrix4x4>::New();
  m_ftTttNeutral->DeepCopy(neutralTransforms[0]);


  try
  {
    m_femCondylarAxisRotationValue = VisualizerUtils::GetDoubleFromFile(m_caseDataFolder + "/intraop/NTKR_FemCondylarAxisRotationValue.dbl");
  }
  catch (const runtime_error& error)
  {
    std::cerr << "FemCondylarAxisRotationValue were not selected as reference!" << std::endl;
  }




  // Load Tibial Atlas Surface
  m_tibialAtlasSurface = VisualizerUtils::ImportSurface(m_caseDataFolder + "/intraop/NTKR_TibiaAtlasSurface.sur");

  // Load Tibial Free Collection Points
  m_tibialFreeCollectionPoints = VisualizerUtils::ImportPoints(m_caseDataFolder + "/intraop/NTKR_TibFreeCollectionPts.mat");

  // Tibia Knee Center
  m_tibialKneeCenter =  VisualizerUtils::ImportPoints(m_caseDataFolder + "/intraop/NTKR_TibKneeCenter.mat");

  // Tibial Checkpoint
  m_tibialCheckpoint = VisualizerUtils::ImportPoints(m_caseDataFolder + "/intraop/NTKR_TibLandmark.mat");

  // Tibial landmarks
  vtkSmartPointer<vtkPoints> lateralLowPoint = VisualizerUtils::ImportPoints(m_caseDataFolder + "/intraop/NTKR_TibLatLowPt.mat");
  vtkSmartPointer<vtkPoints> medialLowPoint = VisualizerUtils::ImportPoints(m_caseDataFolder + "/intraop/NTKR_TibMedLowPt.mat");
  m_lateralMalleolus = VisualizerUtils::ImportPoints(m_caseDataFolder + "/intraop/NTKR_LatMalleolus.mat");
  m_medialMalleolus = VisualizerUtils::ImportPoints(m_caseDataFolder + "/intraop/NTKR_MedMalleolus.mat");

  m_tibialAverageMalleoli = vtkSmartPointer<vtkPoints>::New();
  m_tibialAverageMalleoli->InsertNextPoint(
    (m_lateralMalleolus->GetPoint((vtkIdType)0)[0] + m_medialMalleolus->GetPoint((vtkIdType)0)[0]) / 2.0,
    (m_lateralMalleolus->GetPoint((vtkIdType)0)[1] + m_medialMalleolus->GetPoint((vtkIdType)0)[1]) / 2.0,
    (m_lateralMalleolus->GetPoint((vtkIdType)0)[2] + m_medialMalleolus->GetPoint((vtkIdType)0)[2]) / 2.0);

  m_tibialLandmarks = vtkSmartPointer<vtkPoints>::New();
  VisualizerUtils::AppendPoints(m_tibialKneeCenter, m_tibialLandmarks);
  VisualizerUtils::AppendPoints(lateralLowPoint, m_tibialLandmarks);
  VisualizerUtils::AppendPoints(medialLowPoint, m_tibialLandmarks);
  VisualizerUtils::AppendPoints(m_lateralMalleolus, m_tibialLandmarks);
  VisualizerUtils::AppendPoints(m_medialMalleolus, m_tibialLandmarks);
  try
  {
    m_tubercle = VisualizerUtils::ImportPoints(m_caseDataFolder + "/intraop/NTKR_TibTuberclePt.mat");
    VisualizerUtils::AppendPoints(m_tubercle, m_tibialLandmarks);
  }
  catch (const runtime_error& error)
  {
    std::cerr << "Tibia tubercle was not collected!" << std::endl;
  }

  try
  {
    std::vector< vtkSmartPointer<vtkMatrix4x4> > whitesideTransforms = VisualizerUtils::ImportMatrix(m_caseDataFolder + "/intraop/NTKR_FemWhitesideAxis.mat");
    m_ftTwhitesideAxis = vtkSmartPointer<vtkMatrix4x4>::New();
    m_ftTwhitesideAxis->DeepCopy(whitesideTransforms[0]);

  }
  catch (const runtime_error& error)
  {
    std::cerr << "Whiteside's axis was not collected!" << std::endl;
  }

  try
  {
    std::vector< vtkSmartPointer<vtkMatrix4x4> > apAxisTransforms = VisualizerUtils::ImportMatrix(m_caseDataFolder + "/intraop/NTKR_TibAPAxis.mat");
    m_ttTAPAxis = vtkSmartPointer<vtkMatrix4x4>::New();
    m_ttTAPAxis->DeepCopy(apAxisTransforms[0]);

  }
  catch (const runtime_error& error)
  {
    std::cerr << "Tibia AP axis was not collected!" << std::endl;
  }


  try
  {
    std::vector< vtkSmartPointer<vtkMatrix4x4> > mechAxisTransforms = VisualizerUtils::ImportMatrix(m_caseDataFolder + "/intraop/NTKR_TibFemurMechAxis.mat");
    m_tibtrackerTfemtracker = vtkSmartPointer<vtkMatrix4x4>::New();
    m_tibtrackerTfemtracker->DeepCopy(mechAxisTransforms[0]);
  }
  catch (const runtime_error& error)
  {
    std::cerr << "Tibia Femoral mechanical axis was not collected!" << std::endl;
  }

  m_operativeSide = VisualizerUtils::GetIntFromFile(m_caseDataFolder + "/intraop/NTKR_OpSide.int");
  m_femoralReference  = VisualizerUtils::GetIntFromFile(m_caseDataFolder + "/intraop/NTKR_FemMLRef.int");
  m_tibialReference  = VisualizerUtils::GetIntFromFile(m_caseDataFolder + "/intraop/NTKR_TibRotRef.int");

  std::vector< vtkSmartPointer<vtkMatrix4x4> > transforms = VisualizerUtils::ImportMatrix(m_caseDataFolder + "/intraop/NTKR_ImplantTtibTracker.mat");
  m_ttTti = vtkSmartPointer<vtkMatrix4x4>::New();
  transforms[0]->Invert();
  m_ttTti->DeepCopy(transforms[0]);

  transforms = VisualizerUtils::ImportMatrix(m_caseDataFolder + "/intraop/NTKR_ImplantTfemTracker.mat");
  m_ftTfi = vtkSmartPointer<vtkMatrix4x4>::New();
  transforms[0]->Invert();
  m_ftTfi->DeepCopy(transforms[0]);

}

void NavioTKADataLoader::loadImplants()
{
  if (m_implantFolder.size() > 0)
  {
    // Tibial Implant Data
    string manufacturer = VisualizerUtils::GetStringFromFile(m_caseDataFolder + "/intraop/NTKR_CUT_ImpManu.str");
    string femoralDesign = VisualizerUtils::GetStringFromFile(m_caseDataFolder + "/intraop/NTKR_CUT_FemImpDesign.str");
    string femoralSize = VisualizerUtils::GetStringFromFile(m_caseDataFolder + "/intraop/NTKR_CUT_FemImpSize.str");
    string tibialDesign = VisualizerUtils::GetStringFromFile(m_caseDataFolder + "/intraop/NTKR_CUT_TibImpDesign.str");
    string tibialSize = VisualizerUtils::GetStringFromFile(m_caseDataFolder + "/intraop/NTKR_CUT_TibImpSize.str");
    string tibialThickness = VisualizerUtils::GetStringFromFile(m_caseDataFolder + "/intraop/NTKR_CUT_TibImpThickness.str");

    string patientPlan = VisualizerUtils::GetStringFromFile(m_caseDataFolder + "/config/patient.plan");
    string operativeSide = "Left";
    if (m_operativeSide == TKA_OPERATIVE_SIDE_RIGHT)
      operativeSide = "Right";


    string femoralImplantPath = m_implantFolder + "/" +
                                manufacturer + "/Femur/" + femoralDesign + "/" +
                                femoralSize + "/" + operativeSide + "/display.sur";
    string tibialImplantPath = m_implantFolder + "/" +
                               manufacturer + "/Tibia/" +
                               tibialDesign + "/" +
                               tibialSize + "/" +
                               tibialThickness + "/" +
                               operativeSide + "/display.sur";

    m_femoralImplantSurface = VisualizerUtils::ImportSurface(femoralImplantPath);
    m_tibialImplantSurface = VisualizerUtils::ImportSurface(tibialImplantPath);

    // m_femoralImplantSurface = VisualizerUtils::ImportSurface(femoralImplantPath, m_ftTfi);
    // m_tibialImplantSurface = VisualizerUtils::ImportSurface(tibialImplantPath, m_ttTti);
  }

}

/**
 * @brief      Loads a roms.
 */
void NavioTKADataLoader::loadROMS()
{
  // Load ROM Data
  m_neutralFlexionMat = VisualizerUtils::ImportMatrix(m_caseDataFolder + "/intraop/NTKR_NeutralFlexionMat.mat");
  m_femurNonStressedROMCollection = VisualizerUtils::ImportMatrix(m_caseDataFolder + "/intraop/NTKR_FemNonStressedROMCollection.mat");
  m_femurTTibiaROMStressMedial = VisualizerUtils::ImportMatrix(m_caseDataFolder + "/intraop/NTKR_FemurTTibiaROMStressMedial.mat");
  m_femurTTibiaROMStressLateral = VisualizerUtils::ImportMatrix(m_caseDataFolder + "/intraop/NTKR_FemurTTibiaROMStressLateral.mat");
  m_femurTTibiaPostOpMedialBaselineROM = VisualizerUtils::ImportMatrix(m_caseDataFolder + "/intraop/NTKA_FemurTTibiaPostOpMedialBaselineROM.mat");
  m_femurTTibiaPostOpLateralBaselineROM = VisualizerUtils::ImportMatrix(m_caseDataFolder + "/intraop/NTKA_FemurTTibiaPostOpLateralBaselineROM.mat");
  m_femurTTibiaPostOpROMStressMedial = VisualizerUtils::ImportMatrix(m_caseDataFolder + "/intraop/NTKR_FemurTTibiaPostOpROMStressMedial.mat");
  m_femurTTibiaPostOpROMStressLateral = VisualizerUtils::ImportMatrix(m_caseDataFolder + "/intraop/NTKR_FemurTTibiaPostOpROMStressLateral.mat");
  m_faTtt = vtkSmartPointer<vtkMatrix4x4>::New();
  vtkSmartPointer<vtkTransform> neutralTransform = vtkSmartPointer<vtkTransform>::New();
  neutralTransform->SetMatrix(m_ftTttNeutral);
  neutralTransform->PostMultiply();
  neutralTransform->Concatenate(m_faTft);
  m_faTtt->DeepCopy(neutralTransform->GetMatrix());

  m_faTfi = vtkSmartPointer<vtkMatrix4x4>::New();
  vtkSmartPointer<vtkTransform> femoralPlanningTransform = vtkSmartPointer<vtkTransform>::New();
  femoralPlanningTransform->SetMatrix(m_ftTfi);
  femoralPlanningTransform->PostMultiply();
  femoralPlanningTransform->Concatenate(m_faTft);
  m_faTfi->DeepCopy(femoralPlanningTransform->GetMatrix());


  m_taTti = vtkSmartPointer<vtkMatrix4x4>::New();
  vtkSmartPointer<vtkTransform> tibialPlanningTransform = vtkSmartPointer<vtkTransform>::New();
  tibialPlanningTransform->SetMatrix(m_ttTti);
  tibialPlanningTransform->PostMultiply();
  tibialPlanningTransform->Concatenate(m_taTtt);
  m_taTti->DeepCopy(tibialPlanningTransform->GetMatrix());

  m_faTti = vtkSmartPointer<vtkMatrix4x4>::New();
  vtkSmartPointer<vtkTransform> tibialToFemurPlanningTransform = vtkSmartPointer<vtkTransform>::New();
  tibialToFemurPlanningTransform->SetMatrix(m_ttTti);
  tibialToFemurPlanningTransform->PostMultiply();
  tibialToFemurPlanningTransform->Concatenate(m_faTtt);
  m_faTti->DeepCopy(tibialToFemurPlanningTransform->GetMatrix());

  VisualizerUtils::Multiply(m_neutralFlexionMat, m_faTft);
  VisualizerUtils::Multiply(m_femurNonStressedROMCollection, m_faTft);
  VisualizerUtils::Multiply(m_femurTTibiaROMStressMedial, m_faTft);
  VisualizerUtils::Multiply(m_femurTTibiaROMStressLateral, m_faTft);
  VisualizerUtils::Multiply(m_femurTTibiaPostOpMedialBaselineROM, m_faTft);
  VisualizerUtils::Multiply(m_femurTTibiaPostOpLateralBaselineROM, m_faTft);
  VisualizerUtils::Multiply(m_femurTTibiaPostOpROMStressMedial, m_faTft);
  VisualizerUtils::Multiply(m_femurTTibiaPostOpROMStressLateral, m_faTft);

}

/**
 * @brief      updateFemurAnatomicTransfoms
 */
void NavioTKADataLoader::updateFemurAnatomicTransfoms()
{
  // First calculate the femoral and tibia coordinate systems based on the
  // landmarks
  double leftAxis[3];
  double femHipCenter[3];
  getPoint(m_femoralHipCenter, 0, femHipCenter);

  double femKneeCenter[3];
  getPoint(m_femoralKneeCenter, 0, femKneeCenter);

  switch (m_femoralReference)
  {
  // Epicondyle Reference
  case TKA_FEMUR_ML_REFERENCE_EPICONDYLES:
  {
    double femLatEpicondyle[3];
    getPoint(m_lateralEpicondyle, 0, femLatEpicondyle);
    double femMedEpicondyle[3];
    getPoint(m_medialEpicondyle, 0, femLatEpicondyle);
    // left knee!
    if (m_operativeSide == 1)
      vtkMath::Subtract(femLatEpicondyle, femMedEpicondyle, leftAxis);
    else
      vtkMath::Subtract(femMedEpicondyle, femLatEpicondyle, leftAxis);
  }
  break;

  // White Side's reference
  case TKA_FEMUR_ML_REFERENCE_WHITESIDE:
  {

    // Note: For BBT probe, +Y points from Body to Probe Tip and
    // we collect axis with probe tip pointing posteriorly
    // This is the Anterior-Posterior axis
    double whiteSideAxis[3];
    whiteSideAxis[0] = m_ftTwhitesideAxis->GetElement(0, 1);
    whiteSideAxis[1] = m_ftTwhitesideAxis->GetElement(1, 1);
    whiteSideAxis[2] = m_ftTwhitesideAxis->GetElement(2, 1);

    // Find the Superior-Inferior axis
    double siAxis[3];
    vtkMath::Subtract(femKneeCenter, femHipCenter, siAxis);
    //Mediolateral-Lateral axis, pointing to patient's left
    vtkMath::Cross(siAxis, whiteSideAxis, leftAxis);
  }
  break;
  case TKA_FEMUR_ML_REFERENCE_POSTERIOR_CONDYLE:
  {

    double femMaxPostLatPt[3];
    getPoint(m_maxPosteriorLateralPoint, 0, femMaxPostLatPt);
    double femMaxPostMedPt[3];
    getPoint(m_maxPosteriorMedialPoint, 0, femMaxPostMedPt);
    // left knee!
    if (m_operativeSide == 1)
      vtkMath::Subtract(femMaxPostLatPt, femMaxPostMedPt, leftAxis);
    else
      vtkMath::Subtract(femMaxPostMedPt, femMaxPostLatPt, leftAxis);
  }
  break;
  default:
  {
    stringstream ss;
    ss << __FUNCTION__ << " " << "Un-recognized femoral frame of reference " <<  __FILE__ << " " << __LINE__;
    throw runtime_error(ss.str());
  }
  }

  vtkMath::Normalize(leftAxis);
  double newZ[3], yaxis[3], newx[3];
  vtkMath::Subtract(femHipCenter, femKneeCenter, newZ);
  vtkMath::Normalize(newZ);

  vtkMath::Cross(newZ, leftAxis, yaxis);
  vtkMath::Normalize(yaxis);

  vtkMath::Cross(yaxis, newZ, newx);
  vtkMath::Normalize(newx);
  vtkSmartPointer<vtkMatrix4x4> ftTfa = vtkSmartPointer<vtkMatrix4x4>::New();
  ftTfa->Identity();

  ftTfa->SetElement(0, 0, newx[0]);
  ftTfa->SetElement(1, 0, newx[1]);
  ftTfa->SetElement(2, 0, newx[2]);

  ftTfa->SetElement(0, 1, yaxis[0]);
  ftTfa->SetElement(1, 1, yaxis[1]);
  ftTfa->SetElement(2, 1, yaxis[2]);

  ftTfa->SetElement(0, 2, newZ[0]);
  ftTfa->SetElement(1, 2, newZ[1]);
  ftTfa->SetElement(2, 2, newZ[2]);

  ftTfa->SetElement(0, 3, femKneeCenter[0]);
  ftTfa->SetElement(1, 3, femKneeCenter[1]);
  ftTfa->SetElement(2, 3, femKneeCenter[2]);

  // if posterior condyles were used, apply the offset
  if (m_femoralReference == TKA_FEMUR_ML_REFERENCE_POSTERIOR_CONDYLE)
  {

    double rotation = ((m_operativeSide == TKA_OPERATIVE_SIDE_LEFT) ? 1.0 : -1.0) *
                      m_femCondylarAxisRotationValue;
    vtkSmartPointer<vtkTransform> offsetMat = vtkSmartPointer<vtkTransform>::New();
    offsetMat->RotateWXYZ(rotation, 0, 0, 1);
    offsetMat->PostMultiply();
    offsetMat->Concatenate(ftTfa);
    ftTfa->DeepCopy(offsetMat->GetMatrix());
  }

  m_faTft = vtkSmartPointer<vtkMatrix4x4>::New();
  m_faTft->DeepCopy(ftTfa);
  m_faTft->Invert();
}



/**
 * @brief     updateTibiaAnatomicTransfoms
 */
void NavioTKADataLoader::updateTibiaAnatomicTransfoms()
{
  double trackerPkneeCenter[3];
  getPoint(m_tibialKneeCenter, 0, trackerPkneeCenter);

  double tibiaMedialMalleolus[3];
  getPoint(m_medialMalleolus, 0, tibiaMedialMalleolus);

  double tibiaLateralMalleolus[3];
  getPoint(m_lateralMalleolus, 0, tibiaLateralMalleolus);

  double trackerPankleCenter[3];
  vtkMath::Add(tibiaLateralMalleolus, tibiaMedialMalleolus, trackerPankleCenter);
  vtkMath::MultiplyScalar(tibiaLateralMalleolus, 0.5);
  double rightVleft[3];

  switch (m_tibialReference)
  {

  case TKA_TIBIA_ROT_REFERENCE_AP: // 30
  {
    // Negative mechanical axis
    double kneeVankle[3];
    vtkMath::Subtract(trackerPankleCenter, trackerPkneeCenter, kneeVankle);
    // AP axis
    double apaxis[3];//

    apaxis[0] = m_ttTAPAxis->GetElement(0, 1);
    apaxis[1] = m_ttTAPAxis->GetElement(1, 1);
    apaxis[2] = m_ttTAPAxis->GetElement(2, 1);
    // Left
    vtkMath::Cross(kneeVankle, apaxis, rightVleft);
    vtkMath::Normalize(rightVleft);
    break;
  }

  case TKA_TIBIA_ROT_REFERENCE_TUBERCLE: // 32
  {
    double trackerPtubercle[3];
    getPoint(m_tubercle, 0, trackerPtubercle);

    double trackerVtubAxis[3];
    vtkMath::Subtract(trackerPtubercle, trackerPkneeCenter, trackerVtubAxis);
    vtkMath::Normalize(trackerVtubAxis);

    // Left
    double kneeVankle[3];
    vtkMath::Subtract(trackerPkneeCenter, trackerPankleCenter, kneeVankle);

    double rightVleft[3];
    vtkMath::Cross(kneeVankle, trackerVtubAxis, rightVleft);
    vtkMath::Normalize(rightVleft);
    break;
  }

  case TKA_TIBIA_ROT_REFERENCE_FEMUR: // 33
  {

    double femHipCenter[3];
    getPoint(m_femoralHipCenter, 0, femHipCenter);

    double femKneeCenter[3];
    getPoint(m_femoralKneeCenter, 0, femKneeCenter);

    double trackerVfemMechAxis[3];
    vtkMath::Subtract(femHipCenter, femKneeCenter, trackerVfemMechAxis);

    vtkSmartPointer<vtkMatrix4x4> tibtrackerRfemtracker = vtkSmartPointer<vtkMatrix4x4>::New();
    tibtrackerRfemtracker->Identity();
    tibtrackerRfemtracker->DeepCopy(m_tibtrackerTfemtracker);
    tibtrackerRfemtracker->SetElement(0, 3, 0);
    tibtrackerRfemtracker->SetElement(1, 3, 0);
    tibtrackerRfemtracker->SetElement(2, 3, 0);

    double trackerVfemMechAxis_vec4[4];
    trackerVfemMechAxis_vec4[0] = trackerVfemMechAxis[0];
    trackerVfemMechAxis_vec4[1] = trackerVfemMechAxis[1];
    trackerVfemMechAxis_vec4[2] = trackerVfemMechAxis[2];
    trackerVfemMechAxis_vec4[3] = 0;


    double tibtrackerVfemMechAxis_vec4[4];
    tibtrackerRfemtracker->MultiplyPoint(trackerVfemMechAxis_vec4, tibtrackerVfemMechAxis_vec4);

    double tibtrackerVfemMechAxis[3];
    tibtrackerVfemMechAxis[0] = tibtrackerVfemMechAxis_vec4[0];
    tibtrackerVfemMechAxis[1] = tibtrackerVfemMechAxis_vec4[1];
    tibtrackerVfemMechAxis[2] = tibtrackerVfemMechAxis_vec4[2];


    double kneeVankle[3];
    vtkMath::Subtract(trackerPkneeCenter, trackerPankleCenter, kneeVankle);
    vtkMath::Cross(kneeVankle, tibtrackerVfemMechAxis, rightVleft);
    vtkMath::Normalize(rightVleft);
    break;
  }

  default:
  {
    stringstream ss;
    ss << __FUNCTION__ << " " << "Un-recognized femoral frame of reference " <<  __FILE__ << " " << __LINE__;
    throw runtime_error(ss.str());

  }
  }

  // NMC = No Malleoli Correction
  // MC = Malleoli Corrected


  vtkMath::Normalize(rightVleft);
  double newZ[3], yaxis[3], newx[3];
  vtkMath::Subtract(trackerPankleCenter, trackerPkneeCenter, newZ);
  vtkMath::Normalize(newZ);

  vtkMath::Cross(newZ, rightVleft, yaxis);
  vtkMath::Normalize(yaxis);

  vtkMath::Cross(yaxis, newZ, newx);
  vtkMath::Normalize(newx);
  vtkSmartPointer<vtkMatrix4x4> tibtkrTtibiaNMC = vtkSmartPointer<vtkMatrix4x4>::New();
  tibtkrTtibiaNMC->Identity();

  tibtkrTtibiaNMC->SetElement(0, 0, newx[0]);
  tibtkrTtibiaNMC->SetElement(1, 0, newx[1]);
  tibtkrTtibiaNMC->SetElement(2, 0, newx[2]);

  tibtkrTtibiaNMC->SetElement(0, 1, yaxis[0]);
  tibtkrTtibiaNMC->SetElement(1, 1, yaxis[1]);
  tibtkrTtibiaNMC->SetElement(2, 1, yaxis[2]);

  tibtkrTtibiaNMC->SetElement(0, 2, newZ[0]);
  tibtkrTtibiaNMC->SetElement(1, 2, newZ[1]);
  tibtkrTtibiaNMC->SetElement(2, 2, newZ[2]);

  tibtkrTtibiaNMC->SetElement(0, 3, trackerPkneeCenter[0]);
  tibtkrTtibiaNMC->SetElement(1, 3, trackerPkneeCenter[1]);
  tibtkrTtibiaNMC->SetElement(2, 3, trackerPkneeCenter[2]);


  // The tibia axis should be corrected in the frontal plane to 0.6 degrees
  // more medially.
  vtkSmartPointer<vtkTransform> tibia_NMC_T_tibia_MC = vtkSmartPointer<vtkTransform>::New();
  if (m_operativeSide == 1)
    tibia_NMC_T_tibia_MC->RotateWXYZ(0.6, 0, 1, 0);
  else
    tibia_NMC_T_tibia_MC->RotateWXYZ(-0.6, 0, 1, 0);

  tibia_NMC_T_tibia_MC->PostMultiply();
  tibia_NMC_T_tibia_MC->Concatenate(tibtkrTtibiaNMC);

  m_taTtt = vtkSmartPointer<vtkMatrix4x4>::New();
  m_taTtt->DeepCopy(tibia_NMC_T_tibia_MC->GetMatrix());
  m_taTtt->Invert();

}
