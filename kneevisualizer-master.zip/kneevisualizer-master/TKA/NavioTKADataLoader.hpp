#ifndef NAVIO_TKA_DATA_LOADER_HPP
#define NAVIO_TKA_DATA_LOADER_HPP

#include <vtkPoints.h>
#include <vtkPolyData.h>
#include <vtkSmartPointer.h>
#include <vtkMatrix4x4.h>

class NavioTKADataLoader
{
public:
	NavioTKADataLoader(const std::string& caseDataFolder,
	                   const std::string& implantFolder);
	~NavioTKADataLoader();

	vtkPoints* GetFemoralLandmarkPoints();
	vtkPoints* GetFemoralCheckPoint();
	vtkPoints* GetFemoralKneeCenter();
	vtkPoints* GetFemoralHipCenter();
	vtkPoints* GetFemoralFreeCollectionPoints();
	vtkPolyData* GetFemoralAtlasSurface();
	vtkPolyData* GetFemoralImplantSurface();
	vtkMatrix4x4* GetFemoralImplantToFemoralAnatomicTransform();
	vtkMatrix4x4* GetFemoralTrackerToFemoralAnatomicTransform();


	vtkPoints* GetTibialLandmarkPoints();
	vtkPoints* GetTibialCheckPoint();
	vtkPoints* GetTibialKneeCenter();
	vtkPoints* GetTibialAverageMalleoli();
	vtkPoints* GetTibialFreeCollectionPoints();
	vtkPolyData* GetTibialAtlasSurface();
	vtkPolyData* GetTibialImplantSurface();
	vtkMatrix4x4* GetTibiaImplantToTibialAnatomicTransform();
	vtkMatrix4x4* GetTibiaTrackerToTibialAnatomicTransform();


	vtkMatrix4x4* GetTibiaTrackerToFemoralAnatomicTransform();
	vtkMatrix4x4* GetTibiaImplantToFemoralAnatomicTransform();

	// ROMs
	std::vector<vtkSmartPointer<vtkMatrix4x4> > GetNeutralFlexionMat();
	std::vector<vtkSmartPointer<vtkMatrix4x4> > GetFemurNonStressedROMCollection();
	std::vector<vtkSmartPointer<vtkMatrix4x4> > GetFemurTTibiaROMStressMedial();
	std::vector<vtkSmartPointer<vtkMatrix4x4> > GetFemurTTibiaROMStressLateral();
	std::vector<vtkSmartPointer<vtkMatrix4x4> > GetFemurTTibiaPostOpMedialBaselineROM();
	std::vector<vtkSmartPointer<vtkMatrix4x4> > GetFemurTTibiaPostOpLateralBaselineROM();
	std::vector<vtkSmartPointer<vtkMatrix4x4> > GetFemurTTibiaPostOpROMStressMedial();
	std::vector<vtkSmartPointer<vtkMatrix4x4> > GetFemurTTibiaPostOpROMStressLateral();


private:
	void loadData();
	void loadROMS();
	void loadImplants();
	void updateFemurAnatomicTransfoms();
	void updateTibiaAnatomicTransfoms();

	// Femoral Data
	vtkSmartPointer<vtkPoints> m_maxPosteriorLateralPoint;
	vtkSmartPointer<vtkPoints> m_maxPosteriorMedialPoint;
	vtkSmartPointer<vtkPoints> m_lateralEpicondyle;
	vtkSmartPointer<vtkPoints> m_medialEpicondyle;
	vtkSmartPointer<vtkPoints> m_femoralKneeCenter;
	vtkSmartPointer<vtkPoints> m_femoralHipCenter;
	vtkSmartPointer<vtkPoints> m_femoralLandmarks;
	vtkSmartPointer<vtkPoints> m_femoralCheckpoint;
	vtkSmartPointer<vtkPoints> m_femoralFreeCollectionPoints;
	vtkSmartPointer<vtkPolyData> m_femoralAtlasSurface;
	vtkSmartPointer<vtkPolyData> m_femoralImplantSurface;
	vtkSmartPointer<vtkMatrix4x4> m_ftTfi;
	vtkSmartPointer<vtkMatrix4x4> m_faTfi;
	vtkSmartPointer<vtkMatrix4x4> m_faTft;
	vtkSmartPointer<vtkMatrix4x4> m_ftTwhitesideAxis;
	vtkSmartPointer<vtkMatrix4x4> m_ftTttNeutral;
	vtkSmartPointer<vtkMatrix4x4> m_faTtt;
	vtkSmartPointer<vtkMatrix4x4> m_faTti;
	

	// Tibial Data
	vtkSmartPointer<vtkPoints> m_lateralMalleolus;
	vtkSmartPointer<vtkPoints> m_medialMalleolus;
	vtkSmartPointer<vtkPoints> m_tibialKneeCenter;
	vtkSmartPointer<vtkPoints> m_tibialAverageMalleoli;
	vtkSmartPointer<vtkPoints> m_tibialLandmarks;
	vtkSmartPointer<vtkPoints> m_tibialCheckpoint;
	vtkSmartPointer<vtkPoints> m_tibialFreeCollectionPoints;
	vtkSmartPointer<vtkPolyData> m_tibialAtlasSurface;
	vtkSmartPointer<vtkPolyData> m_tibialImplantSurface;
	vtkSmartPointer<vtkMatrix4x4> m_ttTti;
	vtkSmartPointer<vtkMatrix4x4> m_taTti;
	vtkSmartPointer<vtkMatrix4x4> m_ttTAPAxis;
	vtkSmartPointer<vtkMatrix4x4> m_taTtt;
	vtkSmartPointer<vtkMatrix4x4> m_tibtrackerTfemtracker;
	vtkSmartPointer<vtkPoints> m_tubercle;

	//ROMS
	std::vector< vtkSmartPointer<vtkMatrix4x4> > m_neutralFlexionMat;
	std::vector< vtkSmartPointer<vtkMatrix4x4> > m_femurNonStressedROMCollection;
	std::vector< vtkSmartPointer<vtkMatrix4x4> > m_femurTTibiaROMStressMedial;
	std::vector< vtkSmartPointer<vtkMatrix4x4> > m_femurTTibiaROMStressLateral;
	std::vector< vtkSmartPointer<vtkMatrix4x4> > m_femurTTibiaPostOpMedialBaselineROM;
	std::vector< vtkSmartPointer<vtkMatrix4x4> > m_femurTTibiaPostOpLateralBaselineROM;
	std::vector< vtkSmartPointer<vtkMatrix4x4> > m_femurTTibiaPostOpROMStressMedial;
	std::vector< vtkSmartPointer<vtkMatrix4x4> > m_femurTTibiaPostOpROMStressLateral;

	// Case Data folder
	std::string m_caseDataFolder;
	// Implant Data Folder
	std::string m_implantFolder;

	double m_femCondylarAxisRotationValue;
	// Femoral Reference
	int m_femoralReference;

	// Tibial Reference
	int m_tibialReference;

	// Operative Side
	int m_operativeSide;
};

#endif // NAVIO_TKA_DATA_LOADER_HPP
