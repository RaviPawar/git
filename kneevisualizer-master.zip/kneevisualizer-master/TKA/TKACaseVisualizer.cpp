#include "TKACaseVisualizer.hpp"
#include "../Common/Utils/VisualizerUtils.hpp"
#include <vtkRenderer.h>
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <QStringList>
#include <QDir>
#include <QMessageBox>
#include <string>

using namespace std;

TKACaseVisualizer::TKACaseVisualizer(const std::string& caseIDFolder,
                                     const std::string& implantsFolder,
                                     SceneRenderer *sceneRenderer,
                                     QWidget *parent) :
  m_femLandmarksMapper(NULL),
  m_tibLandmarksMapper(NULL),
  m_femurKneeCenterMapper(NULL),
  m_femCheckPntMapper(NULL),
  m_tibCheckPntMapper(NULL),
  m_femFreeCollectionMapper(NULL),
  m_tibFreeCollectionMapper(NULL),
  m_femAtlasMapper(NULL),
  m_tibAtlasMapper(NULL),
  m_femTrackerMapper(NULL),
  m_tibTrackerMapper(NULL),
  m_femurImplantMapper(NULL),
  m_tibiaImplantMapper(NULL),
  m_femurMechAxisMapper(NULL),
  m_tibiaMechAxisMapper(NULL),
  m_femurButton(NULL),
  m_tibiaButton(NULL),
  m_dataManager(new NavioTKADataLoader(caseIDFolder, implantsFolder)),
  QWidget(parent)
{
  m_sceneRenderer = sceneRenderer;
  loadLandmarks();
  loadFreeCollectionPoints();
  loadAtlasSurfaces();
  loadTrackerSurfaces();
  loadPreOpROMData();
  loadPostOpROMData();
  loadImplants();
  loadAxes();
  addButtonsAndCheckBoxes();
  makeSignalSlotConnections();
  m_sceneRenderer->SetViewToAP();
  double scaling[3] = {1.0, 1.0, 3.0};
  m_sceneRenderer->ResetCameraBounds(m_femAtlasMapper->GetActor(),
                                     m_tibAtlasMapper->GetActor(),
                                     m_femurKneeCenterMapper->GetActor(),
                                     scaling);
  QString info("Info goes here");
  m_sceneRenderer->SetCaseInfo(info);
}



TKACaseVisualizer::~TKACaseVisualizer()
{

  if (m_femLandmarksMapper)
    delete m_femLandmarksMapper;
  m_femLandmarksMapper = NULL;
  if (m_tibLandmarksMapper)
    delete m_tibLandmarksMapper;
  m_tibLandmarksMapper = NULL;
  if (m_femurKneeCenterMapper)
    delete m_femurKneeCenterMapper;
  m_femurKneeCenterMapper = NULL;
  if (m_femCheckPntMapper)
    delete m_femCheckPntMapper;
  m_femCheckPntMapper = NULL;
  if (m_tibCheckPntMapper)
    delete m_tibCheckPntMapper;
  m_tibCheckPntMapper = NULL;
  if (m_femFreeCollectionMapper)
    delete m_femFreeCollectionMapper;
  m_femFreeCollectionMapper = NULL;
  if (m_tibFreeCollectionMapper)
    delete m_tibFreeCollectionMapper;
  m_tibFreeCollectionMapper = NULL;
  if (m_femAtlasMapper)
    delete m_femAtlasMapper;
  m_femAtlasMapper = NULL;
  if (m_tibAtlasMapper)
    delete m_tibAtlasMapper;
  m_tibAtlasMapper = NULL;
  if (m_femTrackerMapper)
    delete m_femTrackerMapper;
  m_femTrackerMapper = NULL;
  if (m_tibTrackerMapper)
    delete m_tibTrackerMapper;
  m_tibTrackerMapper = NULL;
  if (m_femurImplantMapper)
    delete m_femurImplantMapper;
  m_femurImplantMapper = NULL;
  if (m_tibiaImplantMapper)
    delete m_tibiaImplantMapper;
  m_tibiaImplantMapper = NULL;
  if (m_femurMechAxisMapper)
    delete m_femurMechAxisMapper;
  m_femurMechAxisMapper = NULL;
  if (m_tibiaMechAxisMapper)
    delete m_tibiaMechAxisMapper;
  m_tibiaMechAxisMapper = NULL;

  if (m_femurButton)
    delete m_femurButton;
  m_femurButton = NULL;
  if (m_tibiaButton)
    delete m_tibiaButton;
  m_tibiaButton = NULL;

  if (m_dataManager)
    delete m_dataManager;
}


/**
 * @brief      Loads landmarks.
 */
void TKACaseVisualizer::loadLandmarks()
{
  double landmarkcolor[3] = {1.0, 1.0, 0.0};
  m_femLandmarksMapper = new SphereMapper(m_dataManager->GetFemoralLandmarkPoints(),
                                          m_dataManager->GetFemoralTrackerToFemoralAnatomicTransform(),
                                          3.0,
                                          landmarkcolor);
  m_tibLandmarksMapper = new SphereMapper(m_dataManager->GetTibialLandmarkPoints(),
                                          m_dataManager->GetTibiaTrackerToFemoralAnatomicTransform(),
                                          3.0,
                                          landmarkcolor);


  double checkpointColor[3] = {0.59, 0.99, 0.99};
  m_femCheckPntMapper = new SphereMapper(m_dataManager->GetFemoralCheckPoint(),
                                         m_dataManager->GetFemoralTrackerToFemoralAnatomicTransform(),
                                         3.0,
                                         checkpointColor);

  m_tibCheckPntMapper = new SphereMapper(m_dataManager->GetTibialCheckPoint(),
                                         m_dataManager->GetTibiaTrackerToFemoralAnatomicTransform(),
                                         3.0,
                                         checkpointColor);

  m_femurKneeCenterMapper = new SphereMapper(m_dataManager->GetFemoralKneeCenter(),
      m_dataManager->GetFemoralTrackerToFemoralAnatomicTransform(),
      1.0,
      landmarkcolor);
}



void TKACaseVisualizer::loadFreeCollectionPoints()
{
  double freeCollectionColor[3] = {0.0, 1.0, 0.0};

  m_femFreeCollectionMapper = new SphereMapper(
    m_dataManager->GetFemoralFreeCollectionPoints(),
    m_dataManager->GetFemoralTrackerToFemoralAnatomicTransform(),
    1.0,
    freeCollectionColor);


  m_tibFreeCollectionMapper = new SphereMapper(
    m_dataManager->GetTibialFreeCollectionPoints(),
    m_dataManager->GetTibiaTrackerToFemoralAnatomicTransform(),
    1.0,
    freeCollectionColor);

}



void TKACaseVisualizer::loadAtlasSurfaces()
{
  double atlasColor[3] = {1.0, 0.98, 0.74};
  m_femAtlasMapper = new SurfaceMapper(m_dataManager->GetFemoralAtlasSurface(),
                                       m_dataManager->GetFemoralTrackerToFemoralAnatomicTransform(),
                                       atlasColor,
                                       0.5,
                                       m_sceneRenderer->GetActiveRenderingCamera());
  m_tibAtlasMapper = new SurfaceMapper(m_dataManager->GetTibialAtlasSurface(),
                                       m_dataManager->GetTibiaTrackerToFemoralAnatomicTransform(),
                                       atlasColor,
                                       0.5,
                                       m_sceneRenderer->GetActiveRenderingCamera());

  float *femTexCoords = new float[m_dataManager->GetFemoralAtlasSurface()->GetNumberOfPoints()];
  float *tibTexCoords = new float[m_dataManager->GetTibialAtlasSurface()->GetNumberOfPoints()];
  VisualizerUtils::CreateTextureCoordinateArray(m_femAtlasMapper->GetPolyData(),
      m_dataManager->GetFemoralFreeCollectionPoints(),
      femTexCoords,
      0.99,
      2.5,
      10.0);
  VisualizerUtils::CreateTextureCoordinateArray(m_tibAtlasMapper->GetPolyData(),
      m_dataManager->GetTibialFreeCollectionPoints(),
      tibTexCoords,
      0.99,
      2.5,
      10.0);

  m_femAtlasMapper->UpdateColorUsingTextureCoordinates(femTexCoords, m_dataManager->GetFemoralAtlasSurface()->GetNumberOfPoints());
  m_tibAtlasMapper->UpdateColorUsingTextureCoordinates(tibTexCoords, m_dataManager->GetTibialAtlasSurface()->GetNumberOfPoints());

  delete [] femTexCoords;
  delete [] tibTexCoords;


}



void TKACaseVisualizer::loadTrackerSurfaces()
{
  double trackerColor[3] = {0.85, 0.85, 0.85};
  m_femTrackerMapper = new SurfaceMapper(VisualizerUtils::ImportSurface(":/Surfaces/romSfemtracker.sur"),
                                         m_dataManager->GetFemoralTrackerToFemoralAnatomicTransform(),
                                         trackerColor,
                                         1.0,
                                         m_sceneRenderer->GetActiveRenderingCamera());
  m_tibTrackerMapper = new SurfaceMapper(VisualizerUtils::ImportSurface(":/Surfaces/romStibtracker.sur"),
                                         m_dataManager->GetTibiaTrackerToFemoralAnatomicTransform(),
                                         trackerColor,
                                         1.0,
                                         m_sceneRenderer->GetActiveRenderingCamera());

}



void TKACaseVisualizer::loadPreOpROMData()
{

  m_sceneRenderer->AddNewROMToUI("Neutral ROM",
                                 m_dataManager->GetNeutralFlexionMat(),
                                 true);

  m_sceneRenderer->AddNewROMToUI("PreOp - Non Stressed ROM",
                                 m_dataManager->GetFemurNonStressedROMCollection());

  m_sceneRenderer->AddNewROMToUI("PreOp - Medial Stressed ROM",
                                 m_dataManager->GetFemurTTibiaROMStressMedial());

  m_sceneRenderer->AddNewROMToUI("PreOp - Lateral Stressed ROM",
                                 m_dataManager->GetFemurTTibiaROMStressLateral());

}



void TKACaseVisualizer::loadPostOpROMData()
{
  m_sceneRenderer->AddNewROMToUI("PostOp - Medial Baseline ROM",
                                 m_dataManager->GetFemurTTibiaPostOpMedialBaselineROM());
  m_sceneRenderer->AddNewROMToUI("PostOp - Lateral Baseline ROM",
                                 m_dataManager->GetFemurTTibiaPostOpLateralBaselineROM());
  m_sceneRenderer->AddNewROMToUI("PostOp - Medial Stressed ROM",
                                 m_dataManager->GetFemurTTibiaPostOpROMStressMedial());
  m_sceneRenderer->AddNewROMToUI("PostOp - Lateral Stressed ROM",
                                 m_dataManager->GetFemurTTibiaPostOpROMStressLateral());
}


void TKACaseVisualizer::loadImplants()
{
  double implantColor[3] = {0.50, 0.50, 0.50};

  if (m_dataManager->GetFemoralImplantSurface())
  {
    m_femurImplantMapper = new SurfaceMapper(m_dataManager->GetFemoralImplantSurface(),
        m_dataManager->GetFemoralImplantToFemoralAnatomicTransform(),
        implantColor,
        1.0,
        m_sceneRenderer->GetActiveRenderingCamera());
  }



  // if (m_dataManager->GetTibialImplantSurface())
  // {
  //   m_tibiaImplantMapper = new SurfaceMapper(m_dataManager->GetTibialImplantSurface(),
  //       m_dataManager->GetTibiaTrackerToFemoralAnatomicTransform(),
  //       implantColor,
  //       1.0,
  //       m_sceneRenderer->GetActiveRenderingCamera());
  // }

}


void TKACaseVisualizer::loadAxes()
{
  double femurMechColor[3] = {0.0, 0.79, 0.79};
  m_femurMechAxisMapper = new LineMapper(m_dataManager->GetFemoralKneeCenter()->GetPoint((vtkIdType)0),
                                         m_dataManager->GetFemoralHipCenter()->GetPoint((vtkIdType)0),
                                         m_dataManager->GetFemoralTrackerToFemoralAnatomicTransform(),
                                         4.0,
                                         femurMechColor);

  double tibiaMechColor[3] = {0.49, 0.0, 0.99};
  m_tibiaMechAxisMapper = new LineMapper(m_dataManager->GetTibialKneeCenter()->GetPoint((vtkIdType)0),
                                         m_dataManager->GetTibialAverageMalleoli()->GetPoint((vtkIdType)0),
                                         m_dataManager->GetTibiaTrackerToFemoralAnatomicTransform(),
                                         4.0,
                                         tibiaMechColor);

}



void TKACaseVisualizer::addButtonsAndCheckBoxes()
{
  m_femurButton = m_sceneRenderer->AddNewRigidBody("Femur");
  addActorToRenderer(m_femLandmarksMapper->GetActor(), "Femur", "Landmarks");
  addActorToRenderer(m_femCheckPntMapper->GetActor(), "Femur", "Check Point");
  addActorToRenderer(m_femFreeCollectionMapper->GetActor(), "Femur", "Free-Collection");
  addActorToRenderer(m_femAtlasMapper->GetActor(), "Femur", "Atlas");
  addActorToRenderer(m_femTrackerMapper->GetActor(), "Femur", "Tracker");
  addActorToRenderer(m_femurMechAxisMapper->GetActor(), "Femur", "Mechanical Axis");
  if (m_femurImplantMapper)
    addActorToRenderer(m_femurImplantMapper->GetActor(), "Femur", "Implant");


  m_tibiaButton = m_sceneRenderer->AddNewRigidBody("Tibia");
  addActorToRenderer(m_tibLandmarksMapper->GetActor(), "Tibia", "Landmarks");
  addActorToRenderer(m_tibCheckPntMapper->GetActor(), "Tibia", "Check Point");
  addActorToRenderer(m_tibFreeCollectionMapper->GetActor(), "Tibia", "Free-Collection");
  addActorToRenderer(m_tibAtlasMapper->GetActor(), "Tibia", "Atlas");
  addActorToRenderer(m_tibTrackerMapper->GetActor(), "Tibia", "Tracker");
  addActorToRenderer(m_tibiaMechAxisMapper->GetActor(), "Tibia", "Mechanical Axis");
  // if (m_tibiaImplantMapper)
  //   addActorToRenderer(m_tibiaImplantMapper->GetActor(), "Tibia", "Implant");

  m_sceneRenderer->SetBodyForROMMovements("Tibia");
}

/**
 * @brief      Adds an actor to renderer.
 *
 * @param      actor       The actor
 * @param[in]  refFrameID  The reference frame id
 * @param[in]  name        The name
 * @param[in]  flag        The flag
 */
void TKACaseVisualizer::addActorToRenderer(vtkActor* actor, QString refFrameID, QString name)
{
  QCheckBox* checkbox = m_sceneRenderer->AddActorToRenderer(refFrameID.toStdString(),
                        name.toStdString(),
                        actor);
  connect(checkbox, SIGNAL(stateChanged(int)), this, SLOT(slotToggleActor(int)));
  m_checkBoxActorMap[checkbox] = actor;
}


void TKACaseVisualizer::makeSignalSlotConnections()
{
  connect(m_femurButton, SIGNAL(clicked()), this, SLOT(slotToggleFemur()));
  connect(m_tibiaButton, SIGNAL(clicked()), this, SLOT(slotToggleTibia()));
}


void TKACaseVisualizer::slotToggleFemur()
{
  static bool femurVisible = true;
  femurVisible = !femurVisible;
  m_sceneRenderer->ToggleRigidBodyVisibility("Femur", femurVisible);
}



/**
 * @brief      { function_description }
 */
void TKACaseVisualizer::slotToggleTibia()
{
  static bool femurVisible = true;
  femurVisible = !femurVisible;
  m_sceneRenderer->ToggleRigidBodyVisibility("Tibia", femurVisible);
}

/**
 * @brief      { function_description }
 *
 * @param[in]  state  The state
 */
void TKACaseVisualizer::slotToggleActor(int state)
{
  QCheckBox* checkbox = qobject_cast<QCheckBox*>(sender());
  if ( checkbox != NULL )
  {
    m_sceneRenderer->ToggleObjectVisibility(m_checkBoxActorMap[checkbox], state);
  }
}
