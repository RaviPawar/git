#include "TKAAppDelegate.hpp"
#include "TKACaseVisualizer.hpp"
#include "ui_AppDelegate.h"
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <QStringList>


TKAAppDelegate::TKAAppDelegate(QWidget *parent) :
  QMainWindow(parent),
  m_ui(new Ui::AppDelegate)
{
  m_ui->setupUi(this);
  connectSignalsAndSlots();

  QFile f(":style.qss");
  if (!f.exists())
  {
    printf("Unable to set stylesheet, file not found\n");
  }
  else
  {
    f.open(QFile::ReadOnly | QFile::Text);
    QTextStream ts(&f);
    qApp->setStyleSheet(ts.readAll());
  }
  m_ui->menuBar->setVisible(true);
  QMainWindow::showFullScreen();
}



TKAAppDelegate::~TKAAppDelegate()
{
  delete m_ui;
  delete m_sceneRenderer;
}



void TKAAppDelegate::SetCaseIDAndImplantsFolder(std::string caseID, std::string implantsFolder)
{
  m_caseIDFolder = caseID;
  m_implantsFolder = implantsFolder;
  launchAppWidget();
}



void TKAAppDelegate::launchAppWidget()
{
  m_sceneRenderer = new SceneRenderer();
  m_tkavisualizer = new TKACaseVisualizer(m_caseIDFolder, m_implantsFolder, m_sceneRenderer);
  m_ui->hlayoutCenter->addWidget(m_sceneRenderer);
}



void TKAAppDelegate::connectSignalsAndSlots()
{
  connect(m_ui->actionQuit, SIGNAL(triggered()), this, SLOT(slotQuit()));
}



void TKAAppDelegate::slotQuit()
{
  QCoreApplication::exit();
}
