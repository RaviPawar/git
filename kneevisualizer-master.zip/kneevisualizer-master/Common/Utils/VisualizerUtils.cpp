#include "VisualizerUtils.hpp"
#include <QStringList>
#include <QDebug>
#include <QString>
#include <QFile>
#include <QTextStream>
#include <vtkPoints.h>
#include <vtkKdTree.h>
#include <vtkPolyData.h>
#include <vtkMath.h>
#include <vtkPointData.h>
#include <vtkDoubleArray.h>
#include <vtkCellArray.h>
#include <vtkTransform.h>
#include <sstream>

using namespace std;

/**
 * @brief      Creates a texture coordinate array.
 *
 * @param      surfaceData         The surface data
 * @param      regPointArray       The register point array
 * @param      texCoord            The tex coordinate
 * @param[in]  lowConfidenceValue  The low confidence value
 * @param[in]  alphaDistMid        The alpha distance middle
 * @param[in]  alphaDistMax        The alpha distance maximum
 */
void VisualizerUtils::CreateTextureCoordinateArray(vtkPolyData* surfaceData,
    vtkPoints* regPointArray,
    float* texCoord,
    double lowConfidenceValue,
    float alphaDistMid,
    float alphaDistMax)
{

  vtkSmartPointer<vtkKdTree> kdtree = vtkSmartPointer<vtkKdTree>::New();

  float renderMaxSq = alphaDistMax * alphaDistMax;

  // make bbox of point cloud
  const float flMin = -1e7;
  const float flMax = 1e7;
  float xmin = flMax, ymin = flMax, zmin = flMax;
  float xmax = flMin, ymax = flMin, zmax = flMin;

  long numberOfPoints = regPointArray->GetNumberOfPoints();
  for (long int i = 0; i < numberOfPoints; i++)
  {
    double x = regPointArray->GetPoint(i)[0];
    double y = regPointArray->GetPoint(i)[1];
    double z = regPointArray->GetPoint(i)[2];

    xmin = x < xmin ? x : xmin;
    xmax = x > xmax ? x : xmax;
    ymin = y < ymin ? y : ymin;
    ymax = y > ymax ? y : ymax;
    zmin = z < zmin ? z : zmin;
    zmax = z > zmax ? z : zmax;
  }

  kdtree->BuildLocatorFromPoints(regPointArray);

  // enlarge the bbox a little bit
  xmin -= alphaDistMax; ymin -= alphaDistMax; zmin -= alphaDistMax;
  xmax += alphaDistMax; ymax += alphaDistMax; zmax += alphaDistMax;

  for (int i = 0; i < surfaceData->GetNumberOfPoints(); i++)
  {
    double pt[3];
    surfaceData->GetPoint(i, pt);

    if (pt[0] > xmin && pt[0] < xmax &&
        pt[1] > ymin && pt[1] < ymax &&
        pt[2] > zmin && pt[2] < zmax)
    {
      double distsq;
      double distsqMin = flMax;
      vtkIdType id = kdtree->FindClosestPoint(pt, distsq);
      distsqMin = distsqMin < distsq ? distsqMin : distsq;
      if (distsqMin < renderMaxSq)
        texCoord[i] = float(sqrt(distsqMin) / alphaDistMid * 0.25);
      else
        texCoord[i] = lowConfidenceValue; //LOW_CONFIDENCE_VALUE;
    }
    else
      texCoord[i] = lowConfidenceValue; //LOW_CONFIDENCE_VALUE;
  }
}


/**
 * @brief      { function_description }
 *
 * @param[in]  fileName  The file name
 *
 * @return     { description_of_the_return_value }
 */
vtkSmartPointer<vtkPolyData> VisualizerUtils::ImportSurface(const string& fileName)
{

  QFile fin(fileName.c_str());
  if (!fin.exists())
  {
    stringstream ss;
    ss << __FUNCTION__ << " " << "Could not open file: " << " " << fileName << " " << __FILE__ << " " << __LINE__;
    throw runtime_error(ss.str());
  }

  fin.open(QFile::ReadOnly | QFile::Text);
  QTextStream tstream(&fin);


  // Convert filename to string
  long int numPoints = 0;
  tstream >> numPoints;
  cout << fileName.c_str () << " :: The number of points are " << numPoints << endl;
  vtkSmartPointer<vtkPoints> verts = vtkSmartPointer<vtkPoints>::New();
  vtkSmartPointer<vtkCellArray>faces = vtkSmartPointer<vtkCellArray>::New();
  double Listpoints[3];

  // Read co-ordinates
  for (long int n = 0; n < numPoints; n++)
  {
    tstream >> Listpoints[0] >> Listpoints[1] >> Listpoints[2];
    verts->InsertPoint(n, Listpoints);

  }

  long int numFaces = 0;
  tstream >> numFaces;
  //cout << " The number of faces are " << numFaces << endl;

  long int Listfaces[3];

  // Read connectivity
  for (long int n = 0; n < numFaces; n++)
  {
    tstream >> Listfaces[0] >> Listfaces[1] >> Listfaces[2];

    faces->InsertNextCell(3);

    for (int cnt = 0; cnt < 3; cnt++)
    {
      long int idx = Listfaces[cnt];
      if (idx < 0 || idx >= numPoints)
        cout << "wrong index" << endl;
      faces->InsertCellPoint(vtkIdType(idx));
    }

  }

  vtkSmartPointer<vtkPolyData> polydata = vtkSmartPointer<vtkPolyData>::New();
  polydata->SetPoints(verts);
  polydata->SetPolys(faces);
  GeneratePolyDataVertexNormals (polydata);
  polydata->Modified();
  fin.close();

  cout << " Loading Surface " << fileName << endl;
  cout << " #of points " << polydata->GetNumberOfPoints() << endl;
  cout << " #of triangles " << polydata->GetNumberOfPolys() << endl;
  cout << "" << endl;

  return polydata;
}

/**
 * @brief      { function_description }
 *
 * @param[in]  fileName  The file name
 *
 * @return     { description_of_the_return_value }
 */
vtkSmartPointer<vtkPolyData> VisualizerUtils::ImportSurface(const string& fileName,
    vtkMatrix4x4* toMultiply)
{

  QFile fin(fileName.c_str());
  if (!fin.exists())
  {
    stringstream ss;
    ss << __FUNCTION__ << " " << "Could not open file: " << " " << fileName << " " << __FILE__ << " " << __LINE__;
    throw runtime_error(ss.str());
  }

  fin.open(QFile::ReadOnly | QFile::Text);
  QTextStream tstream(&fin);


  // Convert filename to string
  long int numPoints = 0;
  tstream >> numPoints;
  cout << fileName.c_str () << " :: The number of points are " << numPoints << endl;
  vtkSmartPointer<vtkPoints> verts = vtkSmartPointer<vtkPoints>::New();
  vtkSmartPointer<vtkCellArray>faces = vtkSmartPointer<vtkCellArray>::New();
  double Listpoints[3];
  double pointAVec4[4];
  double pointBVec4[4];
  for (int i = 0; i < 4; i++)
  {
    pointAVec4[i] = 0;
    pointBVec4[i] = 0;
  }

  // Read co-ordinates
  for (long int n = 0; n < numPoints; n++)
  {
    tstream >> Listpoints[0] >> Listpoints[1] >> Listpoints[2];
    for (int i = 0; i < 3; i++)
    {
      pointAVec4[i] = Listpoints[i];
    }
    pointAVec4[3] = 0;

    toMultiply->MultiplyPoint(pointAVec4, pointBVec4);
    for (int i = 0; i < 3; i++)
    {
      Listpoints[i] = pointBVec4[i];
    }

    verts->InsertPoint(n, Listpoints);

  }

  long int numFaces = 0;
  tstream >> numFaces;
  //cout << " The number of faces are " << numFaces << endl;

  long int Listfaces[3];

  // Read connectivity
  for (long int n = 0; n < numFaces; n++)
  {
    tstream >> Listfaces[0] >> Listfaces[1] >> Listfaces[2];

    faces->InsertNextCell(3);

    for (int cnt = 0; cnt < 3; cnt++)
    {
      long int idx = Listfaces[cnt];
      if (idx < 0 || idx >= numPoints)
        cout << "wrong index" << endl;
      faces->InsertCellPoint(vtkIdType(idx));
    }

  }

  vtkSmartPointer<vtkPolyData> polydata = vtkSmartPointer<vtkPolyData>::New();
  polydata->SetPoints(verts);
  polydata->SetPolys(faces);
  GeneratePolyDataVertexNormals (polydata);
  polydata->Modified();
  fin.close();

  cout << " Loading Surface " << fileName << endl;
  cout << " #of points " << polydata->GetNumberOfPoints() << endl;
  cout << " #of triangles " << polydata->GetNumberOfPolys() << endl;
  cout << "" << endl;

  return polydata;
}

/**
 * @brief      Import points from file
 *
 * @param[in]  fileName  The file name
 *
 * @return     Loaded points
 */
vtkSmartPointer<vtkPoints> VisualizerUtils::ImportPoints(const string& filepath)
{

  QFile fin(filepath.c_str());
  if (!fin.exists())
  {
    stringstream ss;
    ss << __FUNCTION__ << " " << "Could not open file: " << " " << filepath << " " << __FILE__ << " " << __LINE__;
    throw runtime_error(ss.str());
  }

  fin.open(QFile::ReadOnly | QFile::Text);
  QTextStream tstream(&fin);

  int num_rows = 0, num_columns = 0, num_points = 0;
  tstream >> num_rows >> num_columns >> num_points;


  if (num_columns != 1)
  {
    fin.close();
    stringstream ss;
    ss << __FUNCTION__ << " " << "Wrong file format in points file: " << " " << filepath << " " << __FILE__ << " " << __LINE__;
    runtime_error(ss.str());
  }
  vtkSmartPointer<vtkPoints> points = vtkSmartPointer<vtkPoints>::New();
  double Listpoints[3];
  for (int i = 0; i < num_points; i++)
  {
    tstream >> Listpoints[0] >> Listpoints[1] >> Listpoints[2];
    points->InsertPoint(i, Listpoints);
  }

  fin.close();


  cout << " Loading Points " << filepath << endl;
  cout << " #of points " << points->GetNumberOfPoints() << endl;
  cout << "" << endl;

  return points;

}

/**
 * @brief      Import marices from file
 *
 * @param[in]  fileName  The file name
 *
 * @return     Loaded matrices
 */
vector< vtkSmartPointer<vtkMatrix4x4> > VisualizerUtils::ImportMatrix(const string& filepath)
{
  QFile fin(filepath.c_str());
  if (!fin.exists())
  {
    stringstream ss;
    ss << __FUNCTION__ << " " << "Could not open file: " << " " << filepath << " " << __FILE__ << " " << __LINE__;
    throw runtime_error(ss.str());
  }

  fin.open(QFile::ReadOnly | QFile::Text);
  QTextStream tstream(&fin);

  int num_rows = 0, num_columns = 0, num_transforms = 0;
  float x, y, z;

  tstream >> num_rows >> num_columns >> num_transforms;


  if ((num_rows != 3) || (num_columns != 4) || (num_transforms < 1))
  {
    fin.close();
    stringstream ss;
    ss << __FUNCTION__ << " " << "Wrong file format in points file: " << " " << filepath << " " << __FILE__ << " " << __LINE__;
    throw runtime_error(ss.str());
  }

  vector< vtkSmartPointer<vtkMatrix4x4> > transforms;

  for (int i = 0; i < num_transforms; i++)
  {
    vtkSmartPointer<vtkMatrix4x4> matrix = vtkSmartPointer<vtkMatrix4x4>::New();
    matrix->Identity();

    double xform[3][4];

    tstream >> xform[0][0] >> xform[0][1] >> xform[0][2] >> xform[0][3] >>
            xform[1][0] >> xform[1][1] >> xform[1][2] >> xform[1][3] >>
            xform[2][0] >> xform[2][1] >> xform[2][2] >> xform[2][3];

    for (unsigned int rows = 0; rows < 3; rows++)
      for (unsigned int cols = 0; cols < 4; cols++)
        matrix->SetElement(rows, cols, xform[rows][cols]);

    transforms.push_back(matrix);
  }

  fin.close();
  return transforms;

}


/*------------------------------------------------------------------------------
 *
 *  GeneratePolyDataVertexNormals
 */
/** This function will generate per-vertex normal information using a weighted
 *  average normal based on the areas of the triangles. The information will be
 *  stored in the surface's normals array.
 *
 *    @param   od       Non-NULL pointer to polydata model to generate normals
 *                       for.
 */
/*----------------------------------------------------------------------------*/

void VisualizerUtils::GeneratePolyDataVertexNormals (vtkPolyData* pd) {

  vtkSmartPointer<vtkDoubleArray> pointNormalsArray =
    vtkSmartPointer<vtkDoubleArray>::New();
  pointNormalsArray->SetNumberOfComponents(3); //3d normals (ie x,y,z)
  pointNormalsArray->SetNumberOfTuples(pd->GetNumberOfPoints());

  double zeros[3];
  zeros[0] = 0;
  zeros[1] = 0;
  zeros[2] = 0;

  for (long int i = 0; i < pd->GetNumberOfPoints(); i++)
  {
    pointNormalsArray->SetTuple(vtkIdType(i), zeros);
  }

  double vecX[3], vecY[3], vecZ[3], XcrossY[3];
  double pointA[3], pointB[3], pointC[3];
  unsigned int connectivity[3];


  pd->GetPolys()->InitTraversal();
  vtkSmartPointer<vtkIdList> idList = vtkSmartPointer<vtkIdList>::New();
  long int cnt = 0;
  while (pd->GetPolys()->GetNextCell(idList))
  {
    if (idList->GetNumberOfIds() == 3)
    {
      unsigned int i = 0;
      for (vtkIdType pointId = 0; pointId < idList->GetNumberOfIds(); pointId++)
      {
        connectivity[i] = (int) idList->GetId(pointId);
        i++;
      }

      pd->GetPoint(connectivity[0], pointA);
      pd->GetPoint(connectivity[1], pointB);
      pd->GetPoint(connectivity[2], pointC);
      vtkMath::Subtract (pointB, pointA, vecX);
      vtkMath::Subtract (pointC, pointA, vecY);
      /* calculate the cross product, which is also the normal weighted
         by the inner angle of the triangle */
      vtkMath::Cross(vecX, vecY, XcrossY);

      if (cnt < pd->GetNumberOfPoints())
      {
        pointNormalsArray->GetTuple(vtkIdType(cnt))[0] += XcrossY[0];
        pointNormalsArray->GetTuple(vtkIdType(cnt))[1] += XcrossY[1];
        pointNormalsArray->GetTuple(vtkIdType(cnt))[2] += XcrossY[2];
        cnt++;
      }
    }
  }

  /* normalize the normals */
  vtkIdType numVectors = pointNormalsArray->GetNumberOfTuples();
  for (vtkIdType tupleIdx = 0; tupleIdx < numVectors; ++tupleIdx)
  {
    vtkMath::Normalize (pointNormalsArray->GetTuple(tupleIdx));
  }

  // Add the normals to the points in the pd
  pd->GetPointData()->SetNormals(pointNormalsArray);

}

/**
 * @brief      Appends points.
 *
 * @param      pdSource  The pd source
 * @param      pdTarget  The pd target
 */
void VisualizerUtils::AppendPoints(vtkPoints* pdSource, vtkPoints* pdTarget)
{
  long numberOfPoints = pdSource->GetNumberOfPoints();
  for (long int i = 0; i < numberOfPoints; i++)
  {
    pdTarget->InsertNextPoint(pdSource->GetPoint(i));
  }
}

/**
 * @brief      Gets the string from file.
 *
 * @return     The string from file.
 */
std::string VisualizerUtils::GetStringFromFile(const std::string& fileName)
{
  QFile fin(fileName.c_str());
  if (!fin.exists())
  {
    stringstream ss;
    ss << __FUNCTION__ << " " << "Could not open file: " << " " << fileName << " " << __FILE__ << " " << __LINE__;
    throw runtime_error(ss.str());
  }

  fin.open(QFile::ReadOnly | QFile::Text);

  QTextStream in(&fin);
  QString text = in.readAll();
  fin.close();

  return text.simplified().toStdString();
}

/**
 * @brief      Gets the int from file.
 *
 * @param[in]  fileName  The file name
 *
 * @return     The int from file.
 */
int VisualizerUtils::GetIntFromFile(const std::string& fileName)
{
  QFile fin(fileName.c_str());
  if (!fin.exists())
  {
    stringstream ss;
    ss << __FUNCTION__ << " " << "Could not open file: " << " " << fileName << " " << __FILE__ << " " << __LINE__;
    throw runtime_error(ss.str());
  }

  fin.open(QFile::ReadOnly | QFile::Text);

  QTextStream in(&fin);
  QString text = in.readAll();
  fin.close();

  return text.simplified().toInt();

}

/**
 * @brief      Gets the double from file.
 *
 * @param[in]  fileName  The file name
 *
 * @return     The double from file.
 */
double VisualizerUtils::GetDoubleFromFile(const std::string& fileName)
{
  QFile fin(fileName.c_str());
  if (!fin.exists())
  {
    stringstream ss;
    ss << __FUNCTION__ << " " << "Could not open file: " << " " << fileName << " " << __FILE__ << " " << __LINE__;
    throw runtime_error(ss.str());
  }

  fin.open(QFile::ReadOnly | QFile::Text);

  QTextStream in(&fin);
  QString text = in.readAll();
  fin.close();

  return text.simplified().toDouble();
}

/**
 * @brief      { function_description }
 *
 * @param      transforms  The transforms
 * @param      toMultiply  To multiply
 */
void VisualizerUtils::Multiply(std::vector< vtkSmartPointer<vtkMatrix4x4> >& transforms, vtkMatrix4x4* toMultiply)
{

  for (std::vector< vtkSmartPointer<vtkMatrix4x4> >::iterator it = transforms.begin(); it != transforms.end(); ++it)
  {
    vtkSmartPointer<vtkTransform> transform = vtkSmartPointer<vtkTransform>::New();
    transform->SetMatrix(toMultiply);
    transform->PreMultiply();
    transform->Concatenate(*it);
    (*it)->DeepCopy(transform->GetMatrix());
  }
}
