#ifndef VISUALIZER_UTILS_HPP
#define VISUALIZER_UTILS_HPP

#include <vtkMatrix4x4.h>
#include <vtkPoints.h>
#include <vtkPolyData.h>
#include <vtkSmartPointer.h>
#include <vector>

class vtkPolyData;

class VisualizerUtils
{
public:
	VisualizerUtils();
	~VisualizerUtils();

	static void CreateTextureCoordinateArray(vtkPolyData* surfaceData,
	        vtkPoints* regPointArray,
	        float* texCoord,
	        double lowConfidenceValue,
	        float alphaDistMid,
	        float alphaDistMax);
	static vtkSmartPointer<vtkPolyData> ImportSurface(const std::string& fileName);
	static vtkSmartPointer<vtkPolyData> ImportSurface(const std::string& fileName, vtkMatrix4x4* toMultiply);
	static vtkSmartPointer<vtkPoints> ImportPoints(const std::string& fileName);
	static std::vector< vtkSmartPointer<vtkMatrix4x4> > ImportMatrix(const std::string& fileName);
	static void GeneratePolyDataVertexNormals (vtkPolyData* pd);
	static void AppendPoints (vtkPoints* pdSource, vtkPoints* pdTarget);
	static std::string GetStringFromFile(const std::string& fileName);
	static int GetIntFromFile(const std::string& fileName);
	static double GetDoubleFromFile(const std::string& fileName);
	static void Multiply(std::vector< vtkSmartPointer<vtkMatrix4x4> >& transforms, vtkMatrix4x4* toMultiply);
};

#endif // VISUALIZER_UTILS_HPP
