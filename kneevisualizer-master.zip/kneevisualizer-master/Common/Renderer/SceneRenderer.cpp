#include "SceneRenderer.hpp"
#include "ui_SceneRenderer.h"
#include <vtkRenderer.h>
#include <vtkProperty.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkInteractorStyleTrackballCamera.h>
#include <vtkRendererCollection.h>
#include <vtkLookupTable.h>
#include <vtkTransform.h>
#include <vtkPolyDataMapper.h>
#include <vtkCamera.h>
#include <QString>

/**
 * @brief      Constructs the object.
 *
 * @param      parent  The parent
 */
SceneRenderer::SceneRenderer(QWidget *parent) :
  QWidget(parent),
  m_baseui(new Ui::SceneRenderer)
{
  m_baseui->setupUi(this);
  m_renderer = vtkSmartPointer<vtkRenderer>::New();
  m_romRadioButtons = new QButtonGroup(this);
  m_romRadioButtons->setExclusive(true);
  this->m_baseui->RenderWidget->GetRenderWindow()->AddRenderer(m_renderer);
  this->m_baseui->RenderWidget->GetRenderWindow()->SetAlphaBitPlanes(true);
  this->m_baseui->RenderWidget->GetRenderWindow()->SetMultiSamples(0);
  m_baseui->romSlider->setMinimum(0);
  m_baseui->romSlider->setMaximum(0);
  m_baseui->romSlider->setValue(0);
  m_renderer->GetActiveCamera()->ParallelProjectionOn();
  m_renderer->SetBackground(0.1, 0.1, 0.1);
  m_renderer->SetBackground2(0.5, 0.5, 0.5);
  m_renderer->GradientBackgroundOn();
  m_renderer->SetMaximumNumberOfPeels(4);
  m_renderer->SetOcclusionRatio(0.0);
  m_renderer->SetUseDepthPeeling(true);

  enableViewButtons();
}



/**
 * @brief      Destroys the object.
 */
SceneRenderer::~SceneRenderer()
{
}



QPushButton* SceneRenderer::AddNewRigidBody(const std::string& rigidBody, bool addButton/*=true*/)
{
  if (std::find(m_rigidBodies.begin(), m_rigidBodies.end(), rigidBody) != m_rigidBodies.end())
  {
    std::cerr << "Rigid Body already exists" << std::endl;
    return NULL;
  }
  else
  {
    m_rigidBodies.push_back(rigidBody);
    QPushButton *button;
    if (addButton)
    {
      button = new QPushButton;
      addBodyPushButton(rigidBody, button);
      m_buttons.push_back(button);
    }
    return button;
  }
}



QCheckBox* SceneRenderer::AddActorToRenderer(const std::string& rigidBody,
    const std::string& nameOfObject,
    vtkActor* actor,
    bool addCheckbox /*=true*/)
{
  if (!isRigidBodyAdded(rigidBody))
    throw;

  m_renderer->AddActor(actor);

  QCheckBox *checkbox = NULL;
  if (addCheckbox)
  {
    checkbox = new QCheckBox("");
    addObjectCheckbox(rigidBody, nameOfObject, checkbox);
    m_chkboxCollection[rigidBody].push_back(checkbox);
  }

  m_actorCollection[rigidBody].push_back(actor);
  RenderView();
  return checkbox;
}



void SceneRenderer::AddNewROMToUI(const std::string& nameOfROM,
                                  std::vector<vtkSmartPointer<vtkMatrix4x4> > romdisplayTbody,
                                  bool selected)
{
  QRadioButton *radioButton = new QRadioButton("");
  radioButton->setChecked(false);
  std::string radioButtonLabel = nameOfROM;
  radioButton->setText(QString::fromUtf8(radioButtonLabel.c_str()));
  m_baseui->vRomBoxLayout->addWidget(radioButton);
  m_romRadioButtons->addButton(radioButton);
  radioButton->setChecked(selected);
  m_ROMCollection.insert(std::pair<QAbstractButton*, std::vector<vtkSmartPointer<vtkMatrix4x4> > >(radioButton, romdisplayTbody));
}


void SceneRenderer::SetBodyForROMMovements(const std::string& rigidBody)
{
  if (std::find(m_rigidBodies.begin(), m_rigidBodies.end(), rigidBody) != m_rigidBodies.end())
    m_romRigidBody = rigidBody;
  else
    std::cerr << "Rigid Body does not exist" << std::endl;
}



void SceneRenderer::SetCaseInfo(QString info)
{
  m_baseui->labelCaseInfo->setText(info);

}


void SceneRenderer::RenderView()
{
  m_baseui->RenderWidget->GetRenderWindow()->Render();
}



void SceneRenderer::ResetCameraBounds(vtkActor *actorOne,
                                      vtkActor *actorTwo,
                                      vtkActor *focalActor,
                                      double* scalingFactor)
{
  double bounds[6];
  vtkSmartPointer<vtkTransform> transform = vtkSmartPointer<vtkTransform>::New();

  actorOne->GetMapper()->GetBounds(bounds);
  double minPoint1[] = { bounds[0], bounds[2], bounds[4] };
  double maxPoint1[] = { bounds[1], bounds[3], bounds[5] };
  transform->SetMatrix(actorOne->GetUserMatrix());
  transform->TransformPoint(minPoint1, minPoint1);
  transform->TransformPoint(maxPoint1, maxPoint1);

  actorTwo->GetMapper()->GetBounds(bounds);
  double minPoint2[] = { bounds[0], bounds[2], bounds[4] };
  double maxPoint2[] = { bounds[1], bounds[3], bounds[5] };
  transform->SetMatrix(actorTwo->GetUserMatrix());
  transform->TransformPoint(minPoint2, minPoint2);
  transform->TransformPoint(maxPoint2, maxPoint2);

  focalActor->GetMapper()->GetBounds(bounds);
  double minPoint3[] = { bounds[0], bounds[2], bounds[4] };
  double maxPoint3[] = { bounds[1], bounds[3], bounds[5] };
  transform->SetMatrix(focalActor->GetUserMatrix());
  transform->TransformPoint(minPoint3, minPoint3);
  transform->TransformPoint(maxPoint3, maxPoint3);

  double focalPoint[3];
  for (int i = 0; i < 3; i++)
    focalPoint[i] = (minPoint3[i] + maxPoint3[i]) * 0.5;

  double minPoint[3];
  double maxPoint[3];
  for (int i = 0; i < 3; i++)
  {
    minPoint[i] = std::min(minPoint1[i], minPoint2[i]);
    maxPoint[i] = std::max(maxPoint1[i], maxPoint2[i]);
  }

  double axisLength[3];
  for (int i = 0; i < 3; i++)
  {
    axisLength[i] = std::max(fabs(focalPoint[i] - minPoint[i]), fabs(focalPoint[i] - maxPoint[i]));
  }

  for (int i = 0; i < 3; i++)
  {
    m_cameraBounds[i * 2] = focalPoint[i] - (axisLength[i] / scalingFactor[i]);
    m_cameraBounds[i * 2 + 1] = focalPoint[i] + (axisLength[i] / scalingFactor[i]);
  }

  m_renderer->ResetCamera(m_cameraBounds[0], m_cameraBounds[1],
                          m_cameraBounds[2], m_cameraBounds[3],
                          m_cameraBounds[4], m_cameraBounds[5]);

  m_renderer->ResetCameraClippingRange();
  RenderView();
}



vtkCamera* SceneRenderer::GetActiveRenderingCamera()
{
  return m_renderer->GetActiveCamera();
}



void SceneRenderer::ToggleObjectVisibility(vtkActor* actor, int state)
{
  if (state == 2)
    actor->VisibilityOn();
  else
    actor->VisibilityOff();
  RenderView();
}



void SceneRenderer::ToggleRigidBodyVisibility(const std::string& rigidBody, bool show)
{
  if (std::find(m_rigidBodies.begin(), m_rigidBodies.end(), rigidBody) != m_rigidBodies.end())
  {
    for (std::vector<QCheckBox*>::iterator it = m_chkboxCollection[rigidBody].begin(); it != m_chkboxCollection[rigidBody].end(); ++it)
      (*it)->setChecked(show);
  }
  else
    std::cerr << "Rigid Body does not exist" << std::endl;
}



void SceneRenderer::RemoveRigidBodies()
{
  m_rigidBodies.clear();
}



void SceneRenderer::SetViewToAP()
{
  double focalpt[3], eye[3], newEye[3];
  double viewUp[3] = {0, 0, 1};

  m_renderer->GetActiveCamera()->GetFocalPoint(focalpt);
  m_renderer->GetActiveCamera()->GetPosition(eye);

  double dist = sqrt((focalpt[0] - eye[0]) * (focalpt[0] - eye[0]) +
                     (focalpt[1] - eye[1]) * (focalpt[1] - eye[1]) +
                     (focalpt[2] - eye[2]) * (focalpt[2] - eye[2]));

  newEye[0] = focalpt[0];
  newEye[1] = focalpt[1] - dist;
  newEye[2] = focalpt[2];

  m_renderer->GetActiveCamera()->SetFocalPoint(focalpt);
  m_renderer->GetActiveCamera()->SetPosition(newEye);
  m_renderer->GetActiveCamera()->SetViewUp(viewUp);
  m_renderer->ResetCameraClippingRange();
  m_baseui->RenderWidget->GetRenderWindow()->Render();
}



void SceneRenderer::SetViewToPA()
{
  double focalpt[3], eye[3], newEye[3];
  double viewUp[3] = {0, 0, 1};

  m_renderer->GetActiveCamera()->GetFocalPoint(focalpt);
  m_renderer->GetActiveCamera()->GetPosition(eye);

  double dist = sqrt((focalpt[0] - eye[0]) * (focalpt[0] - eye[0]) +
                     (focalpt[1] - eye[1]) * (focalpt[1] - eye[1]) +
                     (focalpt[2] - eye[2]) * (focalpt[2] - eye[2]));

  newEye[0] = focalpt[0];
  newEye[1] = focalpt[1] + dist;
  newEye[2] = focalpt[2];

  m_renderer->GetActiveCamera()->SetFocalPoint(focalpt);
  m_renderer->GetActiveCamera()->SetPosition(newEye);
  m_renderer->GetActiveCamera()->SetViewUp(viewUp);
  m_renderer->ResetCameraClippingRange();
  m_baseui->RenderWidget->GetRenderWindow()->Render();
}



void SceneRenderer::SetViewToSI()
{
  double focalpt[3], eye[3], newEye[3];
  double viewUp[3] = {0, 1, 0};

  m_renderer->GetActiveCamera()->GetFocalPoint(focalpt);
  m_renderer->GetActiveCamera()->GetPosition(eye);

  double dist = sqrt((focalpt[0] - eye[0]) * (focalpt[0] - eye[0]) +
                     (focalpt[1] - eye[1]) * (focalpt[1] - eye[1]) +
                     (focalpt[2] - eye[2]) * (focalpt[2] - eye[2]));

  newEye[0] = focalpt[0];
  newEye[1] = focalpt[1];
  newEye[2] = focalpt[2] + dist;

  m_renderer->GetActiveCamera()->SetFocalPoint(focalpt);
  m_renderer->GetActiveCamera()->SetPosition(newEye);
  m_renderer->GetActiveCamera()->SetViewUp(viewUp);
  m_renderer->ResetCameraClippingRange();
  m_baseui->RenderWidget->GetRenderWindow()->Render();
}



void SceneRenderer::SetViewToIS()
{
  double focalpt[3], eye[3], newEye[3];
  double viewUp[3] = {0, 1, 0};

  m_renderer->GetActiveCamera()->GetFocalPoint(focalpt);
  m_renderer->GetActiveCamera()->GetPosition(eye);

  double dist = sqrt((focalpt[0] - eye[0]) * (focalpt[0] - eye[0]) +
                     (focalpt[1] - eye[1]) * (focalpt[1] - eye[1]) +
                     (focalpt[2] - eye[2]) * (focalpt[2] - eye[2]));

  newEye[0] = focalpt[0];
  newEye[1] = focalpt[1];
  newEye[2] = focalpt[2] - dist;

  m_renderer->GetActiveCamera()->SetFocalPoint(focalpt);
  m_renderer->GetActiveCamera()->SetPosition(newEye);
  m_renderer->GetActiveCamera()->SetViewUp(viewUp);
  m_renderer->ResetCameraClippingRange();
  m_baseui->RenderWidget->GetRenderWindow()->Render();
}



void SceneRenderer::SetViewToML()
{
  double focalpt[3], eye[3], newEye[3];
  double viewUp[3] = {0, 0, 1};

  m_renderer->GetActiveCamera()->GetFocalPoint(focalpt);
  m_renderer->GetActiveCamera()->GetPosition(eye);

  double dist = sqrt((focalpt[0] - eye[0]) * (focalpt[0] - eye[0]) +
                     (focalpt[1] - eye[1]) * (focalpt[1] - eye[1]) +
                     (focalpt[2] - eye[2]) * (focalpt[2] - eye[2]));

  newEye[0] = focalpt[0] - dist;
  newEye[1] = focalpt[1];
  newEye[2] = focalpt[2];

  m_renderer->GetActiveCamera()->SetFocalPoint(focalpt);
  m_renderer->GetActiveCamera()->SetPosition(newEye);
  m_renderer->GetActiveCamera()->SetViewUp(viewUp);
  m_renderer->ResetCameraClippingRange();
  m_baseui->RenderWidget->GetRenderWindow()->Render();
}



void SceneRenderer::SetViewToLM()
{
  double focalpt[3], eye[3], newEye[3];
  double viewUp[3] = {0, 0, 1};

  m_renderer->GetActiveCamera()->GetFocalPoint(focalpt);
  m_renderer->GetActiveCamera()->GetPosition(eye);

  double dist = sqrt((focalpt[0] - eye[0]) * (focalpt[0] - eye[0]) +
                     (focalpt[1] - eye[1]) * (focalpt[1] - eye[1]) +
                     (focalpt[2] - eye[2]) * (focalpt[2] - eye[2]));

  newEye[0] = focalpt[0] + dist;
  newEye[1] = focalpt[1];
  newEye[2] = focalpt[2];

  m_renderer->GetActiveCamera()->SetFocalPoint(focalpt);
  m_renderer->GetActiveCamera()->SetPosition(newEye);
  m_renderer->GetActiveCamera()->SetViewUp(viewUp);
  m_renderer->ResetCameraClippingRange();
  m_baseui->RenderWidget->GetRenderWindow()->Render();
}



void SceneRenderer::ResetView()
{
  SetViewToAP();
  m_renderer->ResetCamera(m_cameraBounds[0], m_cameraBounds[1],
                          m_cameraBounds[2], m_cameraBounds[3],
                          m_cameraBounds[4], m_cameraBounds[5]);

  m_renderer->ResetCameraClippingRange();
  RenderView();
}


void SceneRenderer::slotROMSelected(QAbstractButton* radioButton)
{
  m_displayTROM.clear();

  for (std::vector<vtkSmartPointer<vtkMatrix4x4> >::iterator it = m_ROMCollection[radioButton].begin();
       it != m_ROMCollection[radioButton].end(); ++it)
    m_displayTROM.push_back(*it);

  m_baseui->romSlider->setMinimum(0);
  m_baseui->romSlider->setMaximum(m_displayTROM.size() - 1);
  m_baseui->romSlider->setValue(0);
}



void SceneRenderer::slotSetROMIndices(int index)
{
  if (m_displayTROM.size() == 0)
    return;

  if ((index >= 0) && index <= m_displayTROM.size() - 1)
  {
    for (std::vector<vtkSmartPointer<vtkActor> >::iterator it = m_actorCollection[m_romRigidBody].begin();
         it != m_actorCollection[m_romRigidBody].end(); ++it)
      (*it)->SetUserMatrix(m_displayTROM[index]);
  }

  RenderView();
}


QCheckBox* SceneRenderer::addObjectCheckbox(const std::string& rigidBody,
    std::string nameOfObject, QCheckBox *checkbox)
{

  checkbox->setChecked(true);
  std::string checkboxLabel = rigidBody + " " + nameOfObject;
  checkbox->setText(QString::fromUtf8(checkboxLabel.c_str()));
  m_baseui->vLayoutAppShowHide->addWidget(checkbox);

  return checkbox;
}



QPushButton* SceneRenderer::addBodyPushButton(const std::string& rigidBody, QPushButton *button)
{
  std::string buttonLabel = rigidBody;
  button->setMaximumWidth(150);
  button->setText(QString::fromUtf8(buttonLabel.c_str()));
  m_baseui->vLayoutAppShowHide->addWidget(button);

  return button;
}


bool SceneRenderer::isRigidBodyAdded(const std::string& rigidBody)
{
  if (std::find(m_rigidBodies.begin(), m_rigidBodies.end(), rigidBody) != m_rigidBodies.end())
    return true;
  else
    return false;
}



void SceneRenderer::enableViewButtons()
{
  connect(m_baseui->apViewButton, SIGNAL(clicked()), this, SLOT(SetViewToAP()));
  connect(m_baseui->paViewButton, SIGNAL(clicked()), this, SLOT(SetViewToPA()));
  connect(m_baseui->mlViewButton, SIGNAL(clicked()), this, SLOT(SetViewToML()));
  connect(m_baseui->lmViewButton, SIGNAL(clicked()), this, SLOT(SetViewToLM()));
  connect(m_baseui->siViewButton, SIGNAL(clicked()), this, SLOT(SetViewToSI()));
  connect(m_baseui->isViewButton, SIGNAL(clicked()), this, SLOT(SetViewToIS()));
  connect(m_baseui->resetButton, SIGNAL(clicked()), this, SLOT(ResetView()));

  connect(m_romRadioButtons, SIGNAL(buttonClicked(QAbstractButton*)), this, SLOT(slotROMSelected(QAbstractButton*)));
  connect(m_baseui->romSlider, SIGNAL(valueChanged(int)), this, SLOT(slotSetROMIndices(int)));
}
