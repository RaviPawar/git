#ifndef OBJECTRENDERER_HPP
#define OBJECTRENDERER_HPP

#include <vtkActor.h>
#include <vtkMatrix4x4.h>
#include <vtkPolyData.h>
#include <vtkPolyDataMapper.h>
#include <vtkProperty.h>
#include <vtkSmartPointer.h>

class ObjectRenderer
{
public:
  ObjectRenderer(vtkPolyData* polydata,
                 vtkProperty* property,
                 vtkMatrix4x4* referenceTself);
  ~ObjectRenderer();
  vtkPolyData* GetPolyData();
  vtkActor* GetActor();
  vtkPolyDataMapper* GetMapper();
  vtkMatrix4x4* GetDisplayTself();
  void UpdateDisplayTSelf(vtkMatrix4x4* displayTself);
  void makeConnections();

private:
  vtkSmartPointer<vtkPolyData> m_polydata;
  vtkSmartPointer<vtkProperty> m_property;
  vtkSmartPointer<vtkMatrix4x4> m_referenceTself;
  vtkSmartPointer<vtkPolyDataMapper> m_mapper;
  vtkSmartPointer<vtkActor> m_actor;
};

#endif //OBJECTRENDERER_HPP
