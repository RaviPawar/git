#ifndef SceneRenderer_HPP
#define SceneRenderer_HPP

#include <vtkActor.h>
#include <vtkCamera.h>
#include <vtkSmartPointer.h>
#include <QButtonGroup>
#include <QCheckBox>
#include <QPushButton>
#include <QRadioButton>
#include <QSlider>
#include <QWidget>
#include <vector>

namespace Ui {
class SceneRenderer;
}

class SceneRenderer : public QWidget
{
  Q_OBJECT

public:
  SceneRenderer(QWidget *parent = 0);
  ~SceneRenderer();

  QPushButton* AddNewRigidBody(const std::string& rigidBody,
                               bool addButton = true);
  QCheckBox* AddActorToRenderer(const std::string& rigidBody,
                                const std::string& nameOfObject,
                                vtkActor* actor,
                                bool addCheckbox = true);
  void AddNewROMToUI(const std::string& nameOfROM,
                     std::vector<vtkSmartPointer<vtkMatrix4x4> > romdisplayTbody,
                     bool selected = false);
  void SetBodyForROMMovements(const std::string& rigidBody);
  vtkCamera* GetActiveRenderingCamera();
  void SetCaseInfo(QString info);
  void RenderView();
  void ResetCameraBounds(vtkActor *actorOne,
                         vtkActor *actorTwo,
                         vtkActor *focalActor,
                         double *scalingFactor);

  void ToggleObjectVisibility(vtkActor* actor, int state);
  void ToggleRigidBodyVisibility(const std::string& rigidBody, bool visible);
  void RemoveRigidBodies();
  vtkSmartPointer<vtkRenderer> GetRenderer() { return m_renderer; }



public slots:

  void SetViewToAP();
  void SetViewToSI();
  void SetViewToML();
  void SetViewToPA();
  void SetViewToIS();
  void SetViewToLM();
  void ResetView();

private slots:

  void slotROMSelected(QAbstractButton* radioButton);
  void slotSetROMIndices(int index);

private:
  QCheckBox* addObjectCheckbox(const std::string& rigidBody,
                               const std::string nameOfObject,
                               QCheckBox *checkbox);
  QPushButton* addBodyPushButton(const std::string& rigidBody,
                                 QPushButton *button);
  bool isRigidBodyAdded(const std::string& rigidBody);
  void enableViewButtons();

  std::map<std::string, std::vector<QCheckBox*> >m_chkboxCollection;
  std::map<std::string, std::vector<vtkSmartPointer<vtkActor> > >m_actorCollection;
  std::map<QAbstractButton*, std::vector<vtkSmartPointer<vtkMatrix4x4> > >m_ROMCollection;
  std::vector<std::string> m_rigidBodies;
  std::vector<QPushButton*> m_buttons;
  std::vector<vtkSmartPointer<vtkMatrix4x4> > m_displayTROM;
  std::string m_romRigidBody;
  vtkSmartPointer<vtkRenderer> m_renderer;
  Ui::SceneRenderer *m_baseui;
  QButtonGroup *m_romRadioButtons;
  double m_cameraBounds[6];

};

#endif //SceneRenderer_HPP
