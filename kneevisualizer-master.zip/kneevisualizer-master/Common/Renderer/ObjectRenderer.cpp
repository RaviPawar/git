#include "ObjectRenderer.hpp"


/**
 * @brief      Constructs the object.
 *
 * @param[in]  polydata        The polydata
 * @param[in]  property        The property
 * @param[in]  referenceTself  The reference tself
 */
ObjectRenderer::ObjectRenderer(vtkPolyData* polydata,
                               vtkProperty* property,
                               vtkMatrix4x4* referenceTself)
{
  m_polydata = vtkSmartPointer<vtkPolyData>::New();
  m_property = vtkSmartPointer<vtkProperty>::New();
  m_referenceTself = vtkSmartPointer<vtkMatrix4x4>::New();
  m_mapper = vtkSmartPointer<vtkPolyDataMapper>::New();
  m_actor = vtkSmartPointer<vtkActor>::New();
  m_polydata->DeepCopy(polydata);
  m_property->DeepCopy(property);
  m_referenceTself->DeepCopy(referenceTself);
  makeConnections();
}



/**
 * @brief      Destroys the object.
 */
ObjectRenderer::~ObjectRenderer()
{

}



/**
 * @brief      Gets the polygon data.
 *
 * @return     The polygon data.
 */
vtkPolyData* ObjectRenderer::GetPolyData()
{
  return m_polydata;
}



/**
 * @brief      Gets the mapper.
 *
 * @return     The mapper.
 */
vtkPolyDataMapper* ObjectRenderer::GetMapper()
{
  return m_mapper;
}



/**
 * @brief      Gets the actor.
 *
 * @return     The actor.
 */
vtkActor* ObjectRenderer::GetActor()
{
  return m_actor;
}



/**
 * @brief      Gets the display tself.
 *
 * @return     The display tself.
 */
vtkMatrix4x4* ObjectRenderer::GetDisplayTself()
{
  return m_referenceTself;
}


/**
 * @brief      { function_description }
 *
 * @param[in]  displayTself  The display tself
 */
void ObjectRenderer::UpdateDisplayTSelf(vtkMatrix4x4* displayTself)
{
  m_actor->SetUserMatrix(displayTself);
}



/**
 * @brief      Makes connections.
 */
void ObjectRenderer::makeConnections()
{
  m_actor->SetProperty(m_property);
  m_actor->SetUserMatrix(m_referenceTself);
  m_mapper->SetInputData(m_polydata);
  m_actor->SetMapper(m_mapper);
}
