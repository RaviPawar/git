#ifndef LINE_MAPPER_HPP
#define LINE_MAPPER_HPP

#include "ObjectMapper.hpp"
#include <vtkLineSource.h>
#include <vtkSmartPointer.h>

class ObjectRenderer;

class LineMapper  : public ObjectMapper
{
public:
  LineMapper(double pointA[3],
             double pointB[3],
             vtkMatrix4x4* displayTself,
             double width,
             double color[3],
             double opacity = 1.0);
  ~LineMapper();
  void UpdateColor(double color[3], double opacity = 1.0);
  void UpdateWidth(double width);
  void UpdateDisplayMatrix(vtkMatrix4x4* displayTself);
  vtkActor* GetActor();

private:
  void setupConnections();
  void createLine(double pointA[3],
                  double pointB[3],
                  vtkMatrix4x4* displayTself,
                  double width,
                  double color[3],
                  double opacity = 1.0);

  ObjectRenderer *m_objRender;
  vtkSmartPointer<vtkLineSource> m_linesrc;
};

#endif // LINE_MAPPER_HPP
