#include "LineMapper.hpp"
#include "../Renderer/ObjectRenderer.hpp"
#include <vtkPoints.h>
#include <vtkPointData.h>
#include <vtkLine.h>
#include <vtkCellArray.h>

/**
 * @brief      Constructs the object.
 *
 * @param[in]  pointA        The point a
 * @param[in]  pointB        The point b
 * @param[in]  displayTself  The display tself
 * @param[in]  width         The width
 * @param      color         The color
 * @param[in]  opacity       The opacity
 */
LineMapper::LineMapper(double pointA[3],
                       double pointB[3],
                       vtkMatrix4x4* displayTself,
                       double width,
                       double color[3],
                       double opacity /*= 1.0*/) :
  ObjectMapper()
{
  m_linesrc = vtkSmartPointer<vtkLineSource>::New();
  createLine(pointA, pointB, displayTself, width, color, opacity);
  setupConnections();
}

/**
 * @brief      Destroys the object.
 */
LineMapper::~LineMapper()
{

}


/**
 * @brief      Update Color
 *
 * @param      color    The color
 * @param[in]  opacity  The opacity
 */
void LineMapper::UpdateColor(double color[3], double opacity/*=1.0*/)
{
  m_objRender->GetActor()->GetProperty()->SetColor(color);
  m_objRender->GetActor()->GetProperty()->SetOpacity(opacity);
  m_linesrc->Update();
}


/**
 * @brief      Update Width
 *
 * @param[in]  width  The width
 */
void LineMapper::UpdateWidth(double width)
{
  m_objRender->GetActor()->GetProperty()->SetLineWidth(width);
  m_linesrc->Update();
}



/**
 * @brief      { function_description }
 *
 * @param[in]  displayTself  The display tself
 */
void LineMapper::UpdateDisplayMatrix(vtkMatrix4x4* displayTself)
{
  m_objRender->UpdateDisplayTSelf(displayTself);
}



/**
 * @brief      Gets the actor.
 *
 * @return     The actor.
 */
vtkActor* LineMapper::GetActor()
{
  return m_objRender->GetActor();
}



/**
 * @brief      { function_description }
 */
void LineMapper::setupConnections()
{
  m_objRender->GetMapper()->SetInputConnection(m_linesrc->GetOutputPort());
  m_objRender->GetActor()->SetMapper(m_objRender->GetMapper());
  m_linesrc->Update();
}



/**
 * @brief      Creates a line.
 *
 * @param[in]  pointA        The point a
 * @param[in]  pointB        The point b
 * @param[in]  displayTself  The display tself
 * @param[in]  width         The width
 * @param      color         The color
 * @param[in]  opacity       The opacity
 */
void LineMapper::createLine(double pointA[3],
                            double pointB[3],
                            vtkMatrix4x4* displayTself,
                            double width,
                            double color[3],
                            double opacity /*= 1.0*/)
{
  m_linesrc->SetPoint1(pointA);
  m_linesrc->SetPoint2(pointB);
  vtkSmartPointer<vtkProperty> property = vtkSmartPointer<vtkProperty>::New();
  property->SetColor(color);
  property->SetOpacity(opacity);
  property->SetLineWidth(width);
  vtkSmartPointer<vtkPolyData> polydata = vtkSmartPointer<vtkPolyData>::New();
  polydata->DeepCopy(m_linesrc->GetOutput());
  polydata->Modified();
  m_objRender = new ObjectRenderer(polydata, property, displayTself);
}
