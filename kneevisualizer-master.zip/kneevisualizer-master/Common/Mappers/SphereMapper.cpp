#include "SphereMapper.hpp"
#include "../Renderer/ObjectRenderer.hpp"

/**
 * @brief      Constructs the object.
 *
 * @param[in]  points        The points
 * @param[in]  displayTself  The display tself
 * @param[in]  radius        The radius
 * @param      color         The color
 * @param[in]  ouble         The ouble
 */
SphereMapper::SphereMapper(vtkPoints* points,
                           vtkMatrix4x4* displayTself,
                           double radius,
                           double color[3],
                           double opacity/*=1.0*/)  :
  ObjectMapper()
{
  m_points = vtkSmartPointer<vtkPoints>::New();
  m_spheresrc = vtkSmartPointer<vtkSphereSource>::New();
  createSphere(points, displayTself, radius, color, opacity);
  setupConnections();
}

/**
 * @brief      Destroys the object.
 */
SphereMapper::~SphereMapper()
{

}

/**
 * @brief      { function_description }
 *
 * @param      color    The color
 * @param[in]  opacity  The opacity
 */
void SphereMapper::UpdateColor(double color[3], double opacity/*= 1.0*/)
{
  m_objRender->GetActor()->GetProperty()->SetColor(color);
  m_objRender->GetActor()->GetProperty()->SetOpacity(opacity);
  m_spheresrc->Update();
  m_glyph3D->SetSourceConnection(m_spheresrc->GetOutputPort());
  m_glyph3D->SetInputData(m_objRender->GetPolyData());
  m_glyph3D->Update();
}

/**
 * @brief      { function_description }
 *
 * @param[in]  radius  The radius
 */
void SphereMapper::UpdateRadius(double radius)
{
  m_spheresrc->SetRadius(radius);
  m_spheresrc->Update();
  m_glyph3D->SetSourceConnection(m_spheresrc->GetOutputPort());
  m_glyph3D->SetInputData(m_objRender->GetPolyData());
  m_glyph3D->Update();
}

/**
 * @brief      { function_description }
 *
 * @param[in]  displayTself  The display tself
 */
void SphereMapper::UpdateDisplayMatrix(vtkMatrix4x4* displayTself)
{
  m_objRender->UpdateDisplayTSelf(displayTself);
}

/**
 * @brief      Gets the actor.
 *
 * @return     The actor.
 */
vtkActor* SphereMapper::GetActor()
{
  return m_objRender->GetActor();
}

/**
 * @brief      { function_description }
 */
void SphereMapper::setupConnections()
{
  m_objRender->GetMapper()->SetInputConnection(m_glyph3D->GetOutputPort());
  m_objRender->GetActor()->SetMapper(m_objRender->GetMapper());
  m_spheresrc->Update();
  m_glyph3D->SetSourceConnection(m_spheresrc->GetOutputPort());
  m_glyph3D->SetInputData(m_objRender->GetPolyData());
  m_glyph3D->Update();
}



/**
 * @brief      Creates a sphere.
 *
 * @param[in]  points        The points
 * @param[in]  displayTself  The display tself
 * @param[in]  radius        The radius
 * @param      color         The color
 * @param[in]  opacity       The opacity
 */
void SphereMapper::createSphere(vtkPoints* points,
                                vtkMatrix4x4* displayTself,
                                double radius,
                                double color[3],
                                double opacity/*=1.0*/)

{
  m_glyph3D = vtkSmartPointer<vtkGlyph3D>::New();

  m_spheresrc->SetRadius(radius);
  vtkSmartPointer<vtkProperty> property = vtkSmartPointer<vtkProperty>::New();
  property->SetColor(color);
  property->SetOpacity(opacity);

  m_points->DeepCopy(points);
  vtkSmartPointer<vtkPolyData> polydata = vtkSmartPointer<vtkPolyData>::New();
  polydata->SetPoints(m_points);
  polydata->Modified();

  m_glyph3D->SetColorModeToColorByScalar();
  m_glyph3D->SetSourceConnection(m_spheresrc->GetOutputPort());
  m_glyph3D->SetInputData(polydata);
  m_glyph3D->ScalingOff();

  m_objRender = new ObjectRenderer(polydata, property, displayTself);
}
