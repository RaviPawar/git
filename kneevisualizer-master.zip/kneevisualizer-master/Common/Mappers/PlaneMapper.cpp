#include "PlaneMapper.hpp"
#include "../Renderer/ObjectRenderer.hpp"


/**
 * @brief      Constructs the object.
 *
 * @param[in]  center        The center
 * @param[in]  normal        The normal
 * @param[in]  anatomyTself  The anatomy tself
 */
PlaneMapper::PlaneMapper(double center[3],
                         double normal[3],
                         vtkMatrix4x4* anatomyTself):
  ObjectRenderer(createPlane(center, normal), anatomyTself)
{
  m_planesrc = vtkSmartPointer<vtkPlaneSource>::New();
}



/**
 * @brief      Destroys the object.
 */
PlaneMapper::~PlaneMapper()
{

}



/**
 * @brief      { function_description }
 *
 * @param      color    The color
 * @param[in]  opacity  The opacity
 */
void PlaneMapper::UpdateColor(double color[3], double opacity/*=1.0*/)
{
  GetActor()->GetProperty()->SetColor(color);
  GetActor()->GetProperty()->SetOpacity(opacity);
  m_planesrc->Update();
}



/**
 * @brief      { function_description }
 *
 * @param[in]  xResolution  The x resolution
 * @param[in]  yResolution  The y resolution
 */
void PlaneMapper::UpdateResolution(int xResolution, int yResolution)
{
  m_planesrc->SetResolution(xResolution, yResolution);
  m_planesrc->Update();
}



void PlaneMapper::SetupConnections()
{
  GetMapper()->SetInputConnection(m_planesrc->GetOutputPort());
  GetActor()->SetMapper(GetMapper());
}



/**
 * @brief      Creates a plane.
 *
 * @param[in]  center  The center
 * @param[in]  normal  The normal
 *
 * @return     { description_of_the_return_value }
 */
vtkSmartPointer<vtkPolyData> PlaneMapper::createPlane(double center[3], double normal[3])
{
  m_planesrc->SetCenter(center);
  m_planesrc->SetNormal(normal);
  m_planesrc->Update();

  return m_planesrc->GetOutput();
}
