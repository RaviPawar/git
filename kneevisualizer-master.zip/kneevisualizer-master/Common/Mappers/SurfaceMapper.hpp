#ifndef SURFACE_MAPPER_HPP
#define SURFACE_MAPPER_HPP

#include "ObjectMapper.hpp"
#include <vtkLookupTable.h>
#include <vtkFloatArray.h>
#include <vtkProperty.h>
#include <vtkImageData.h>
#include <vtkDepthSortPolyData.h>
#include <vtkSmartPointer.h>
#include <vtkCamera.h>

class vtkImageData;
class ObjectRenderer;

class SurfaceMapper  : public ObjectMapper
{
public:
    SurfaceMapper(vtkPolyData* sur,
                  vtkMatrix4x4* displayTself,
                  double color[3],
                  double opacity,
                  vtkCamera* camera);
    ~SurfaceMapper();
    void UpdateColor(double color[3], double opacity = 1.0);
    void UpdateColorUsingTextureCoordinates(float*& textureCoords, int size);
    void UpdateDisplayMatrix(vtkMatrix4x4* displayTself);
    vtkActor* GetActor();
    vtkPolyData* GetPolyData();

private:
    void setupConnections();
    void createSurface(vtkPolyData* sur,
                       vtkMatrix4x4* displayTself,
                       double color[3],
                       double opacity,
                       vtkCamera* camera);
    vtkSmartPointer<vtkImageData> initAlphaStripImage(vtkLookupTable* lut, float minAlpha = 0.1, float maxAlpha = 0.7);
    vtkSmartPointer<vtkImageData> initAlphaStripImage2(vtkLookupTable* lut, float minAlpha = 0.1, float maxAlpha = 0.7);
    ObjectRenderer *m_objRender;
    vtkSmartPointer<vtkDepthSortPolyData> m_dspd;
    vtkSmartPointer<vtkImageData> m_alphaStripImage;
    vtkSmartPointer<vtkFloatArray> m_texCoords;
    vtkSmartPointer<vtkLookupTable> m_lookupTable;
};

#endif // SURFACE_MAPPER_HPP
