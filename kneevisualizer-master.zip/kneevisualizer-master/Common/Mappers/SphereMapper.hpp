#ifndef SPHERE_MAPPER_HPP
#define SPHERE_MAPPER_HPP

#include "ObjectMapper.hpp"
#include <vtkSphereSource.h>
#include <vtkPoints.h>
#include <vtkPointData.h>
#include <vtkSmartPointer.h>
#include <vtkGlyph3D.h>


class ObjectRenderer;

class SphereMapper : public ObjectMapper
{
public:
  SphereMapper(vtkPoints* points,
               vtkMatrix4x4* displayTself,
               double radius,
               double color[3],
               double opacity = 1.0);
  ~SphereMapper();

  void UpdateColor(double color[3], double opacity = 1.0);
  void UpdateRadius(double radius);
  void UpdateDisplayMatrix(vtkMatrix4x4* displayTself);
  vtkActor* GetActor();

private:
  void setupConnections();
  void createSphere(vtkPoints* points,
                    vtkMatrix4x4* displayTself,
                    double radius,
                    double color[3],
                    double opacity = 1.0);

  ObjectRenderer *m_objRender;
  vtkSmartPointer<vtkSphereSource> m_spheresrc;
  vtkSmartPointer<vtkGlyph3D> m_glyph3D;
  vtkSmartPointer<vtkPoints> m_points;
  std::vector<vtkIdType> m_idVector;
};

#endif // SPHERE_MAPPER_HPP
