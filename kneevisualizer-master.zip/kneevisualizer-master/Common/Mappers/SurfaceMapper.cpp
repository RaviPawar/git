#include "SurfaceMapper.hpp"
#include "../Renderer/ObjectRenderer.hpp"
#include <vtkCellArray.h>
#include <vtkFloatArray.h>
#include <vtkTexture.h>
#include <vtkPointData.h>
#include <vtkPolyDataNormals.h>
#include <vtkImageData.h>
#include <QDebug>
/**
 * @brief      Constructs the object.
 *
 * @param[in]  sur           The sur
 * @param[in]  displayTself  The display tself
 * @param      color         The color
 * @param[in]  opacity       The opacity
 * @param      camera        The camera
 */
SurfaceMapper::SurfaceMapper(vtkPolyData* sur,
                             vtkMatrix4x4* displayTself,
                             double color[3],
                             double opacity,
                             vtkCamera* camera)  :
  ObjectMapper(),
  m_alphaStripImage(NULL),
  m_texCoords(NULL)
{
  m_dspd = vtkSmartPointer<vtkDepthSortPolyData>::New();

  createSurface(sur, displayTself, color, opacity, camera);
  setupConnections();
}



/**
 * @brief      Destroys the object.
 */
SurfaceMapper::~SurfaceMapper()
{
  m_alphaStripImage = NULL;
  m_texCoords = NULL;
}



/**
 * @brief      { function_description }
 *
 * @param      color    The color
 * @param[in]  opacity  The opacity
 */
void SurfaceMapper::UpdateColor(double color[3], double opacity/*=1.0*/)
{
  m_objRender->GetActor()->GetProperty()->SetColor(color);
  m_objRender->GetActor()->GetProperty()->SetOpacity(opacity);
  m_dspd->Update();
}



/**
 * @brief      { function_description }
 *
 * @param      texCoordsValue  The tex coordinates value
 * @param[in]  size            The size
 */
void SurfaceMapper::UpdateColorUsingTextureCoordinates(float*& texCoordsValue, int size)
{

  m_lookupTable = vtkSmartPointer<vtkLookupTable>::New();
  m_lookupTable->SetNumberOfTableValues(512);
  m_lookupTable->SetRange(0.1, 0.7);

  m_texCoords = vtkSmartPointer<vtkFloatArray>::New();
  m_texCoords->SetName("TextureCoordinates");
  m_texCoords->SetNumberOfComponents(3);

  for (int i = 0; i < size; i++)
  {
    float value[3] = {texCoordsValue[i], 0.0, 0.0};
    m_texCoords->InsertNextTuple(value);
  }
  if (m_objRender->GetPolyData()->GetPointData())
    m_objRender->GetPolyData()->GetPointData()->SetTCoords(m_texCoords);
  else
    qDebug() << " m_objRender->GetPolyData()->GetPointData() is NULL " ;

  m_alphaStripImage = initAlphaStripImage(m_lookupTable);

  vtkSmartPointer<vtkTexture> texture = vtkSmartPointer<vtkTexture>::New();
  texture->SetInputData(m_alphaStripImage);
  texture->SetLookupTable(m_lookupTable);
  texture->RepeatOn();
  texture->EdgeClampOn();
  texture->SetBlendingMode(vtkTexture::VTK_TEXTURE_BLENDING_MODE_REPLACE);

  texture->InterpolateOff();
  texture->Update();
  m_objRender->GetMapper()->SetInputData(m_objRender->GetPolyData());
  m_objRender->GetActor()->SetMapper(m_objRender->GetMapper());
  m_objRender->GetActor()->SetTexture(texture);

  m_dspd->Update();
}



/**
 * @brief      { function_description }
 *
 * @param[in]  displayTself  The display tself
 */
void SurfaceMapper::UpdateDisplayMatrix(vtkMatrix4x4* displayTself)
{
  m_objRender->UpdateDisplayTSelf(displayTself);
}



/**
 * @brief      Gets the actor.
 *
 * @return     The actor.
 */
vtkActor* SurfaceMapper::GetActor()
{
  return m_objRender->GetActor();
}



/**
 * @brief      Gets the polygon data.
 *
 * @return     The polygon data.
 */
vtkPolyData* SurfaceMapper::GetPolyData()
{
  return m_objRender->GetPolyData();
}



/**
 * @brief      { function_description }
 */
void SurfaceMapper::setupConnections()
{
  m_dspd->SetInputData(m_objRender->GetPolyData());
  m_objRender->GetMapper()->SetInputConnection(m_dspd->GetOutputPort());
  m_objRender->GetActor()->SetMapper(m_objRender->GetMapper());
}



/**
 * @brief      Creates a surface.
 *
 * @param[in]  sur           The sur
 * @param[in]  displayTself  The display tself
 * @param      color         The color
 * @param[in]  opacity       The opacity
 * @param      camera        The camera
 */
void SurfaceMapper::createSurface(vtkPolyData* sur,
                                  vtkMatrix4x4* displayTself,
                                  double color[3],
                                  double opacity,
                                  vtkCamera* camera)
{
  vtkSmartPointer<vtkPolyData> polydata = vtkSmartPointer<vtkPolyData>::New();
  vtkSmartPointer<vtkProperty> property = vtkSmartPointer<vtkProperty>::New();
  property->SetColor(color);
  property->SetOpacity(opacity);


  vtkSmartPointer<vtkPoints> verts = vtkSmartPointer<vtkPoints>::New();
  verts->DeepCopy(sur->GetPoints());

  vtkSmartPointer<vtkCellArray> faces = vtkSmartPointer<vtkCellArray>::New();
  faces->DeepCopy(sur->GetPolys());

  polydata->SetPoints(verts);
  polydata->SetPolys(faces);
  polydata->Modified();

  // Generate normals
  vtkSmartPointer<vtkPolyDataNormals> normalGenerator = vtkSmartPointer<vtkPolyDataNormals>::New();
  normalGenerator->SetInputData(polydata);
  normalGenerator->ComputePointNormalsOn();
  normalGenerator->ComputeCellNormalsOn();
  normalGenerator->FlipNormalsOn();
  normalGenerator->SplittingOff();

  m_dspd->SetInputConnection(normalGenerator->GetOutputPort());
  m_dspd->SetDirectionToBackToFront();
  m_dspd->SetVector(1, 1, 1);
  m_dspd->SetCamera(camera);
  m_dspd->SortScalarsOff();
  m_dspd->Update();

  m_objRender = new ObjectRenderer(m_dspd->GetOutput(), property, displayTself);
}


/**
 * @brief      { function_description }
 *
 * @param      lut       The lut
 * @param[in]  minAlpha  The minimum alpha
 * @param[in]  maxAlpha  The maximum alpha
 *
 * @return     { description_of_the_return_value }
 */
vtkSmartPointer<vtkImageData> SurfaceMapper::initAlphaStripImage(vtkLookupTable* lut, float minAlpha, float maxAlpha)
{
  unsigned int textureWidth = 512;
  vtkSmartPointer<vtkImageData> alphaStripImage = vtkSmartPointer<vtkImageData>::New();
  alphaStripImage->SetDimensions(textureWidth, 1, 1);
  alphaStripImage->AllocateScalars(VTK_FLOAT, 1);

  int i;
  for (i = 0; i < textureWidth / 4; i++)
  {
    float value = 1.0 / (exp((double)(i - 100) * 0.2) + 1.0) * (maxAlpha - minAlpha) + minAlpha;
    float* pixel = static_cast<float*>(alphaStripImage->GetScalarPointer(i, 0, 0));
    pixel[0] = value;
    m_lookupTable->SetTableValue(i , 1.0, 0.98, 0.74, 1 - value );
  }
  for (i = textureWidth / 4; i < textureWidth; i++)
  {
    float* pixel = static_cast<float*>(alphaStripImage->GetScalarPointer(i, 0, 0));
    pixel[0] = minAlpha;
    m_lookupTable->SetTableValue(i, 1.0, 0.98, 0.74, 1 - minAlpha );
  }
  m_lookupTable->Build();

  return alphaStripImage;
}



/* vtkSmartPointer<vtkImageData> SurfaceMapper::initAlphaStripImage2(RGBA *rgbaArray, float minAlpha,
              float maxAlpha)
*
* This function assigns colour to the bone surface based on distance of the
* surface from the closest user collected point.
* Yellow - the same mesh that is visible to the user in normal mode
* yellow : distance ~ 0.0-2.5mm
* green  : distance ~ 2.5-5.0mm
* blue   : distance ~ 5.0-7.5mm
* red    : distance ~ >7.5mm
*/
vtkSmartPointer<vtkImageData> SurfaceMapper::initAlphaStripImage2(vtkLookupTable* lut, float minAlpha, float maxAlpha)
{
  unsigned int textureWidth = 512;
  vtkSmartPointer<vtkImageData> alphaStripImage = vtkSmartPointer<vtkImageData>::New();
  alphaStripImage->SetDimensions(textureWidth, 1, 1);
  alphaStripImage->AllocateScalars(VTK_FLOAT, 1);

  int yellowStart = 0;
  int greenStart = 128; /*(2.5mm)*/
  int blueStart = 256; /*(5mm)*/
  int redStart = 384; /*(7.5mm)*/

  for (int i = yellowStart; i < greenStart; i++)
  {
    float value = 1 / (exp((i - 100) * 0.2) + 1) * maxAlpha;
    float* pixel = static_cast<float*>(alphaStripImage->GetScalarPointer(i, 0, 0));
    pixel[0] = value;
    m_lookupTable->SetTableValue(i, 0.588, 0.933, 1.0, 1 - value );
  }

  for (int i = greenStart; i < blueStart; i++)
  {
    float* pixel = static_cast<float*>(alphaStripImage->GetScalarPointer(i, 0, 0));
    pixel[0] = minAlpha;
    m_lookupTable->SetTableValue(i, 0.0, 1.0, 0.0, 1 - minAlpha );
  }

  for (int i = blueStart; i < redStart; i++)
  {
    float* pixel = static_cast<float*>(alphaStripImage->GetScalarPointer(i, 0, 0));
    pixel[0] = minAlpha;
    m_lookupTable->SetTableValue(i, 1.0, 0.0, 0.0, 1 - minAlpha );
  }

  for (int i = redStart; i < textureWidth; i++)
  {
    float* pixel = static_cast<float*>(alphaStripImage->GetScalarPointer(i, 0, 0));
    pixel[0] = minAlpha;
    m_lookupTable->SetTableValue(i, 0.0, 0.0, 1.0, -minAlpha );
  }

  m_lookupTable->Build();

  return alphaStripImage;
}

