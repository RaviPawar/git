#pragma once

#include <vtkMatrix4x4.h>
#include <vtkActor.h>

class ObjectMapper
{
public:
	ObjectMapper() {};
	virtual ~ObjectMapper() {};

	virtual void UpdateDisplayMatrix(vtkMatrix4x4* displayTself) = 0;
	virtual vtkActor* GetActor() = 0;;
	virtual void UpdateColor(double color[3], double opacity = 1.0) = 0;

protected:
	virtual void setupConnections() = 0;

};
