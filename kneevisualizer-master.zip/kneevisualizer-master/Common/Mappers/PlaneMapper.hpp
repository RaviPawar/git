#ifndef PLANE_MAPPER_HPP
#define PLANE_MAPPER_HPP

#include "ObjectMapper.hpp"
#include <vtkPlaneSource.h>
#include <vtkSmartPointer.h>
#include <vtkPolyData.h>

class ObjectRenderer;

class PlaneMapper : public ObjectRenderer
{
public:
  PlaneMapper(double center[3],
              double normal[3],
              vtkMatrix4x4* anatomyTself);
  ~PlaneMapper();

  void UpdateColor(double color[3], double opacity = 1.0);
  void UpdateResolution(int xResolution, int yResolution);
  void SetupConnections();

private:
  vtkSmartPointer<vtkPolyData> createPlane(double center[3], double normal[3]);
  vtkSmartPointer<vtkPlaneSource> m_planesrc;
};

#endif // PLANE_MAPPER_HPP
